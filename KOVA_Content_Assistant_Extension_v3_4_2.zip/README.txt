KOVA Content Assistant Extension v3.4.2
=======================================

Bản v3.4.2 là bản ổn định sau lỗi v3.4.1 bị rỗng workflow/treo UI.

Fix chính
---------
1. Luôn khôi phục workflow mặc định nếu storage bị rỗng/lỗi.
2. Workflow dropdown không còn bị trống.
3. Cloud Sync force update workflow cùng id từ GitHub.
4. Sau sync refresh lại toàn bộ UI, Workflow tab và Prompt Editor.
5. Nếu index/workflow cloud lỗi, extension vẫn giữ được workflow local/default, không bị treo.
6. Loại bỏ các biến Project Config cũ còn sót trong prompt mặc định.

Cách test
---------
1. Cài/reload v3.4.2.
2. Mở extension, phải thấy Workflow Profile có FE Stories Workflow.
3. Bấm Sync Cloud Workflows.
4. Log phải có dạng:
   Sync xong: thêm 0, cập nhật 1 · FE Stories Workflow (fe_stories)

Lưu ý
-----
- Workflow cloud cùng id sẽ ghi đè bản local cùng id.
- Workflow copy/local khác id không bị ghi đè.
- Nếu team muốn chỉnh riêng, hãy Nhân bản cho dự án mới.

Update version.json
-------------------
{
  "version": "3.4.2",
  "notes": "Stable workflow state. Fixed blank workflow list and force cloud sync.",
  "download_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant/raw/main/KOVA_Content_Assistant_Extension_v3_4_2.zip",
  "repo_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant"
}
