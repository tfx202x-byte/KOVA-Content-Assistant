KOVA Content Assistant Extension v3.4.1
=======================================

Bản v3.4.1 fix Cloud Workflow Sync.

Lỗi cũ
------
Bạn sửa workflows/FE-Stories.json trên GitHub, commit, bấm Sync Cloud Workflows nhưng extension không thấy thay đổi rõ ràng.

Cách fix trong v3.4.1
---------------------
1. Force replace workflow cùng id
   - Nếu GitHub workflow có id "fe_stories"
   - Máy user cũng có "fe_stories"
   - Sync sẽ ghi đè định nghĩa workflow bằng bản GitHub mới nhất

2. Refresh UI sau sync
   - Cập nhật lại Workflow Profile
   - Cập nhật lại Workflow JSON tab
   - Cập nhật lại Prompt Editor nếu đang mở

3. Log rõ workflow nào được cập nhật
   - Ví dụ:
     Sync xong: thêm 0, cập nhật 1 · FE Stories Workflow (fe_stories)

4. Hỗ trợ index.json đơn giản
   - { "workflows": ["FE-Stories.json"] }
   - { "workflows": [{ "id": "fe_stories", "file": "FE-Stories.json" }] }
   - ["FE-Stories.json"]

Cách dùng
---------
1. Upload v3.4.1 zip lên GitHub.
2. Sửa version.json.
3. Cài/reload extension v3.4.1.
4. Sửa workflows/FE-Stories.json trên GitHub.
5. Commit.
6. Bấm Sync Cloud Workflows.
7. Kiểm tra log phải thấy "cập nhật 1".

Lưu ý
-----
- Workflow server cùng id sẽ ghi đè bản local.
- Nếu user muốn chỉnh riêng, hãy bấm Nhân bản cho dự án mới để tạo id khác.
- Workflow copy/local khác id sẽ không bị ghi đè khi sync.

Update version.json
-------------------
{
  "version": "3.4.1",
  "notes": "Fixed Cloud Workflow Sync. Force updates cloud workflows by id and refreshes UI.",
  "download_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant/raw/main/KOVA_Content_Assistant_Extension_v3_4_1.zip",
  "repo_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant"
}
