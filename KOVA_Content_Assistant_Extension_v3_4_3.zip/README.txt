KOVA Content Assistant Extension v3.4.3
=======================================

Bản v3.4.3 fix mạnh Cloud Workflow Sync.

Fix chính
---------
1. Thêm host permissions cho:
   - https://raw.githubusercontent.com/*
   - https://github.com/*

2. Log rõ từng URL fetch:
   - FETCH index.json
   - FETCH FE-Stories.json
   - FETCH HT-Stories.json
   - HTTP status từng file

3. Nếu index.json lỗi, tự fallback:
   - FE-Stories.json
   - HT-Stories.json

4. Nếu workflow storage bị rỗng/lỗi:
   - tự khôi phục workflow mặc định

5. Có nút:
   - Khôi phục mặc định

6. Sync cloud cùng id sẽ force update theo GitHub.

Cách test
---------
1. Reload extension v3.4.3.
2. Bấm Khôi phục mặc định nếu dropdown bị rỗng.
3. Bấm Sync Cloud Workflows.
4. Xem log phải có:
   FETCH STATUS 200: index.json
   FETCH STATUS 200: FE-Stories.json
   FETCH STATUS 200: HT-Stories.json
   Sync xong: ...

Update version.json
-------------------
{
  "version": "3.4.3",
  "notes": "Robust Cloud Workflow Sync with GitHub permissions, verbose logs and fallback.",
  "download_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant/raw/main/KOVA_Content_Assistant_Extension_v3_4_3.zip",
  "repo_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant"
}
