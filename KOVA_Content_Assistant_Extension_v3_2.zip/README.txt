KOVA Content Assistant Extension v3.2
=====================================

Bản v3.2 thêm Cloud Workflow Sync.

Ý tưởng
-------
Extension chỉ là Core Engine. Những thứ hay thay đổi như:
- workflow
- prompt
- project config mặc định
- export rule
- auto step

được lưu trên GitHub dạng JSON.

Khi bạn sửa workflow/prompt trên GitHub, user chỉ cần bấm Sync Cloud Workflows, không cần tải extension mới.

GitHub cần có cấu trúc
---------------------
KOVA-Content-Assistant
├── version.json
├── workflows
│   ├── index.json
│   ├── FE-Stories.json
│   ├── HiddenTale.json
│   └── ShadowCipher.json
└── KOVA_Content_Assistant_Extension_v3_2.zip

File workflows/index.json mẫu
-----------------------------
{
  "workflows": [
    {
      "id": "fe_stories",
      "name": "FE Stories",
      "file": "FE-Stories.json"
    },
    {
      "id": "hidden_tale",
      "name": "HiddenTale",
      "file": "HiddenTale.json"
    }
  ]
}

File workflow mẫu
-----------------
Có thể export workflow hiện tại từ Workflow JSON Editor, hoặc tạo file theo format:

{
  "id": "fe_stories",
  "name": "FE Stories Workflow",
  "version": "1.0",
  "autoReviewSteps": ["analysis", "skeleton", "summary"],
  "export": { "mode": "chapters_only_clean" },
  "autoFullScript": {
    "chapter1Step": "chapter1",
    "loopStep": "nextChapter",
    "finalStep": "finalChapter"
  },
  "steps": [
    {
      "id": "analysis",
      "name": "B1 Phân tích",
      "saveTo": "outputs",
      "outputKey": "analysis",
      "prompt": "..."
    }
  ]
}

Cách dùng
---------
1. Upload workflows/index.json và các workflow JSON lên GitHub.
2. Mở extension.
3. Bấm Sync Cloud Workflows.
4. Workflow cloud sẽ xuất hiện trong Workflow Profile.
5. Chọn workflow và chạy automation.

Lưu ý quan trọng
----------------
- Workflow local tự tạo vẫn được giữ.
- Cloud workflow cùng id sẽ được cập nhật theo GitHub.
- Muốn chỉnh riêng workflow cloud mà không bị sync ghi đè, hãy bấm Nhân bản workflow rồi sửa bản copy.
- Update extension chỉ cần khi sửa engine/UI, không cần khi chỉ sửa prompt/workflow.

Update version.json cho v3.2
----------------------------
{
  "version": "3.2.0",
  "notes": "Added Cloud Workflow Sync from GitHub JSON.",
  "download_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant/raw/main/KOVA_Content_Assistant_Extension_v3_2.zip",
  "repo_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant"
}
