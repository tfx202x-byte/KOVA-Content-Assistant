KOVA Content Assistant Extension v3.3
=====================================

Bản v3.3 tối ưu sự tiện lợi khi quản lý nhiều dự án/workflow.

Vấn đề trước đây
----------------
Khi sửa prompt từng bước B1, B2, B3... bạn phải nhớ lưu từng bước.
Muốn backup/upload lên GitHub cũng phải mở Workflow JSON thủ công.

Bản v3.3 thêm Workflow Pack Manager
-----------------------------------
1. Lưu toàn bộ Workflow
   - Lưu tất cả step, prompt, config, export rule của workflow hiện tại.
   - Không cần nhớ từng bước rời rạc.

2. Export Workflow JSON
   - Xuất ra 1 file JSON hoàn chỉnh.
   - File này có thể upload thẳng lên GitHub workflows/.

3. Import Workflow JSON
   - Nhập workflow từ file JSON.
   - Tự thêm vào Workflow Profile.

4. Nhân bản cho dự án mới
   - Clone workflow hiện tại.
   - Tự đổi tên project config.
   - Phù hợp khi tạo kênh/dự án mới cùng form nhưng khác DNA.

5. Lưu bước + Workflow
   - Trong Prompt Step Editor có nút mới:
     "Lưu bước + Workflow"
   - Vừa lưu prompt bước hiện tại, vừa lưu lại toàn bộ workflow pack.

Workflow Pack gồm gì?
---------------------
{
  "id": "...",
  "name": "...",
  "version": "...",
  "autoReviewSteps": [...],
  "autoFullScript": {...},
  "export": {...},
  "steps": [...],
  "projectConfig": {...}
}

Cách dùng tối ưu
----------------
Khi tạo dự án mới:
1. Chọn workflow gần giống.
2. Bấm "Nhân bản cho dự án mới".
3. Bấm "Sửa Project Config" để đổi DNA/style/độ dài.
4. Nếu cần, sửa prompt từng bước.
5. Bấm "Lưu bước + Workflow" hoặc "Lưu toàn bộ Workflow".
6. Bấm "Export Workflow JSON" để backup/upload GitHub.

Đưa workflow lên GitHub
-----------------------
1. Export Workflow JSON.
2. Upload file JSON vào thư mục workflows/ trên GitHub.
3. Sửa workflows/index.json để thêm workflow mới.
4. User bấm Sync Cloud Workflows là nhận workflow mới.

Update version.json cho v3.3
----------------------------
{
  "version": "3.3.0",
  "notes": "Added Workflow Pack Manager: save/export/import full workflow with project config.",
  "download_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant/raw/main/KOVA_Content_Assistant_Extension_v3_3.zip",
  "repo_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant"
}
