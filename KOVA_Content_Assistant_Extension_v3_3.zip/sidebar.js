const EXT_VERSION = "3.3.0";
const STORAGE_KEY = "kovaContentAssistantV3";
const OLD_KEYS = ["kovaContentAssistantV2", "kovaProjectV14", "kovaProjectV11", "kovaProject"];

const UPDATE_INFO_URL = "https://raw.githubusercontent.com/tfx202x-byte/KOVA-Content-Assistant/main/version.json";
const UPDATE_REPO_URL = "https://github.com/tfx202x-byte/KOVA-Content-Assistant";
const CLOUD_WORKFLOW_INDEX_URL = "https://raw.githubusercontent.com/tfx202x-byte/KOVA-Content-Assistant/main/workflows/index.json";
const CLOUD_WORKFLOW_BASE_URL = "https://raw.githubusercontent.com/tfx202x-byte/KOVA-Content-Assistant/main/workflows/";

const FE_WORKFLOW = {
  id: "fe_stories",
  name: "FE Stories Workflow",
  version: "3.0",
  description: "Family Echoes style: B1→B3 review, then auto full script.",
  autoReviewSteps: ["analysis", "skeleton", "summary"],
  export: {
    mode: "chapters_only_clean"
  },
  autoFullScript: {
    chapter1Step: "chapter1",
    loopStep: "nextChapter",
    finalStep: "finalChapter"
  },
  steps: [
    {
      id: "analysis",
      name: "B1 Phân tích",
      saveTo: "outputs",
      outputKey: "analysis",
      prompt: `Tôi sẽ cung cấp cho bạn:
TIÊU ĐỀ MỚI: {{NEW_TITLE}}

KỊCH BẢN GỐC:
{{ORIGINAL_SCRIPT}}

Nhiệm vụ của bạn là phân tích kịch bản gốc này dưới góc nhìn storytelling YouTube, giữ chân người xem, cảm xúc, tính viral và SEO.

PROJECT CONFIG:
{{PROJECT_CONFIG}}

Mục tiêu phân tích là để rút ra cấu trúc, điểm mạnh, điểm yếu, keyword và các điểm cần cải thiện trước khi xây dựng một câu chuyện mới theo tiêu đề mới.

Yêu cầu:
1. Phân tích cấu trúc kịch bản theo các phần nếu có:
Hook → Intro/Setup → Build/Rising Conflict → Climax → Twist/Reveal → Reflection/Emotional Payoff → CTA/Closing.

2. Chỉ ra điểm mạnh nổi bật.

3. Chỉ ra ĐIỂM YẾU VÀ CÁCH CẢI THIỆN:
Hãy đặt đúng tiêu đề mục là: "3. Điểm yếu và cách cải thiện"

4. Trích xuất SEO keywords thành 3 nhóm:
- Keyword chính
- Keyword phụ
- Keyword liên quan
Hãy đặt đúng tiêu đề mục là: "4. SEO keywords"

5. Kết luận ngắn.

Yêu cầu trình bày rõ ràng, có mục, không lan man, ưu tiên tính ứng dụng cao.`
    },
    {
      id: "skeleton",
      name: "B2 Skeleton",
      saveTo: "outputs",
      outputKey: "skeleton",
      prompt: `Tôi sẽ cung cấp cho bạn:
TIÊU ĐỀ MỚI: {{NEW_TITLE}}
ĐỀ XUẤT MỚI: {{DE_XUAT_MOI}}
SEO KEYWORDS: {{SEO_KEYWORDS}}

GHI CHÚ CHỈNH SỬA THÊM TỪ TÔI:
{{EXTRA_NOTES}}

Nhiệm vụ của bạn là viết skeleton dàn ý nhiều chương cho một kịch bản YouTube storytelling hoàn toàn mới.

PROJECT CONFIG:
{{PROJECT_CONFIG}}

Yêu cầu:
- Câu chuyện phải bám sát Channel DNA: {{CHANNEL_DNA}}
- Story world: {{STORY_WORLD}}
- Target length: {{TARGET_LENGTH}}
- Chapter length: {{CHAPTER_LENGTH}}
- Style rules:
{{STYLE_RULES}}
- Forbidden rules:
{{FORBIDDEN_RULES}}
- Câu chuyện believable trong đời sống Mỹ.
- Số chương: tự quyết định số chương hiệu quả nhất. Tối thiểu trên 5 chương.
- Output bắt đầu bằng:
Suggested Chapter Count:
Estimated Total Length:

Với mỗi chương, trình bày:
Chapter Title
Purpose:
Main Beats:
Core Conflict:
Secret / Reveal / Emotional Turn:
Escalation Value:
Human Value Layer:
SEO Keyword Placement:
End Hook / Cliffhanger:`
    },
    {
      id: "summary",
      name: "B3 Tóm tắt",
      saveTo: "outputs",
      outputKey: "summary",
      prompt: `Hãy tóm tắt ngắn gọn câu chuyện mới bạn vừa viết khung dàn ý bên trên, để tôi hiểu câu chuyện và kiểm tra tính logic.

Dàn ý đã duyệt:
{{SKELETON}}`
    },
    {
      id: "chapter1",
      name: "B4 Chương 1",
      saveTo: "chapter",
      chapterNumber: 1,
      prompt: `Dựa vào dàn ý Chương 1 đã được duyệt trước đó.
Nhiệm vụ của bạn là viết Chương 1 bằng tiếng Anh, bám sát tuyệt đối dàn ý đã duyệt.
Độ dài mục tiêu: {{CHAPTER_LENGTH}}.

Yêu cầu:
- Chỉ viết nội dung chương.
- Không ghi số chương, không ghi tiêu đề chương ở đầu output.
- Không phân tích, không giải thích, không heading/subheading.
- Output bắt đầu ngay bằng câu chuyện.
- POV/style: {{CONFIG:pov}}.
- Mở đầu bằng opening hook 50–80 từ.
- Sau hook chèn nguyên văn:
“Welcome to today’s story. If you enjoy emotional drama and shocking twists, don’t forget to like this video and subscribe for more unforgettable stories. And before we begin, let me know where you’re watching from in the comments.”
- Sau đó ghi đúng:
END OF HOOK
- Sau đó viết một câu chuyển ngắn, tự nhiên để quay về điểm bắt đầu.

Dàn ý đã duyệt:
{{SKELETON}}`
    },
    {
      id: "nextChapter",
      name: "B5 Chương tiếp",
      saveTo: "chapter",
      chapterNumber: "{{CHAPTER_NUMBER}}",
      prompt: `Hãy viết chương tiếp theo của câu chuyện bằng tiếng Anh, bám đúng dàn ý đã duyệt và nối mạch tự nhiên với các chương trước đó.
Độ dài mục tiêu: {{CHAPTER_LENGTH}}.
Lưu ý đây chưa phải chương cuối, đây là chương {{CHAPTER_NUMBER}} của {{CHAPTER_COUNT}} chương.

Yêu cầu:
- Chỉ viết nội dung chương bằng tiếng Anh.
- Không ghi số thứ tự chương ở đầu.
- Không ghi tiêu đề chương, không heading, không subheading, không bullet point, không meta commentary.
- Output phải bắt đầu ngay bằng câu chuyện.
- POV/style: {{CONFIG:pov}}.
- Cuối chương có hook hoặc cliffhanger mạnh.

Dàn ý đã duyệt:
{{SKELETON}}

Tóm tắt câu chuyện:
{{SUMMARY}}

Các chương đã viết:
{{CHAPTERS}}`
    },
    {
      id: "finalChapter",
      name: "B6 Chương cuối",
      saveTo: "chapter",
      chapterNumber: "{{CHAPTER_COUNT}}",
      prompt: `Hãy viết chương cuối của câu chuyện bằng tiếng Anh, bám đúng dàn ý đã duyệt và nối mạch chặt chẽ với các chương trước đó.
Độ dài mục tiêu: 400–600 từ hoặc theo Project Config: {{CHAPTER_LENGTH}}.

Yêu cầu:
- Chỉ viết nội dung chương.
- Không ghi số thứ tự chương ở đầu.
- Không heading, subheading, bullet point hoặc meta commentary.
- Output phải bắt đầu ngay bằng câu chuyện.
- Hoàn tất xung đột chính.
- Trả payoff cho bí mật, cảm xúc, lựa chọn đạo đức và quan hệ gia đình.
- CTA cuối chương thật tự nhiên, ngắn, mềm.

Dàn ý đã duyệt:
{{SKELETON}}

Tóm tắt câu chuyện:
{{SUMMARY}}

Các chương đã viết:
{{CHAPTERS}}`
    },
    {
      id: "description",
      name: "B7 Mô tả",
      saveTo: "outputs",
      outputKey: "description",
      prompt: `Tiêu đề mới:
{{NEW_TITLE}}

Tóm tắt video:
{{SUMMARY}}

Nhiệm vụ của bạn là viết:
1 dòng SEO thô
1 đoạn mô tả bằng tiếng Anh dài 60–70 từ
1 bản dịch tiếng Việt
5 tags tối ưu nhất cho video`
    }
  ]
};

const SIMPLE_WORKFLOW = {
  id: "simple_script",
  name: "Simple Script Workflow",
  version: "3.0",
  description: "Generic workflow for projects that do not need chapters.",
  autoReviewSteps: ["idea", "outline"],
  export: { mode: "all_outputs_clean" },
  steps: [
    {
      id: "idea",
      name: "B1 Idea Analysis",
      saveTo: "outputs",
      outputKey: "idea",
      prompt: `Analyze this topic/input and propose the strongest content angle.

TOPIC:
{{NEW_TITLE}}

INPUT:
{{ORIGINAL_SCRIPT}}

NOTES:
{{EXTRA_NOTES}}`
    },
    {
      id: "outline",
      name: "B2 Outline",
      saveTo: "outputs",
      outputKey: "outline",
      prompt: `Create a clear outline based on this analysis:

{{OUTPUT:idea}}`
    },
    {
      id: "script",
      name: "B3 Full Script",
      saveTo: "outputs",
      outputKey: "script",
      prompt: `Write the full script based on this outline:

{{OUTPUT:outline}}

Requirements:
- No headings
- No meta commentary
- Start directly with the script`
    }
  ]
};


const DEFAULT_PROJECT_CONFIG = {
  projectName: "FE Stories",
  language: "English",
  channelDNA: "emotional family drama, family secrets, hidden identities, betrayal, reunion, moral justice, healing",
  storyWorld: "modern United States, realistic everyday life",
  targetLength: "6,000–9,000 words",
  chapterLength: "600–800 words per middle chapter, 400–600 words for final chapter",
  pov: "Third-person, past tense",
  audience: "English-speaking YouTube audience who enjoys emotional storytelling and shocking but believable twists",
  styleRules: [
    "Believable and emotionally rich",
    "No unrealistic coincidence",
    "Clear rising tension and emotional payoff",
    "Natural American English",
    "Easy to read aloud by voice AI",
    "No headings or chapter labels in final script"
  ],
  forbiddenRules: [
    "No reused plot",
    "No meta commentary",
    "No chapter number in final content",
    "No title/heading in chapter output",
    "No unrealistic or forced twist"
  ],
  exportMode: "chapters_only_clean"
};

let state = freshState();
let isRunning = false;
let stopRequested = false;

function clone(obj) {
  return JSON.parse(JSON.stringify(obj));
}

function freshState(workflows, activeWorkflowId) {
  const wf = workflows || {
    [FE_WORKFLOW.id]: clone(FE_WORKFLOW),
    [SIMPLE_WORKFLOW.id]: clone(SIMPLE_WORKFLOW)
  };
  const active = activeWorkflowId && wf[activeWorkflowId] ? activeWorkflowId : Object.keys(wf)[0];
  return {
    appVersion: EXT_VERSION,
    projectCode: "KOVA-" + new Date().toISOString().slice(11,19).replaceAll(":",""),
    newTitle: "",
    originalScript: "",
    extraNotes: "",
    totalChapterCount: "",
    nextChapterNumber: 2,
    activeWorkflowId: active,
    activeOutput: "workflow:" + active,
    outputs: {},
    extracted: { deXuatMoi: "", seoKeywords: "" },
    chapters: {},
    projectConfig: clone(DEFAULT_PROJECT_CONFIG),
    workflows: wf,
    cloudSync: {
      lastSyncedAt: "",
      lastStatus: "",
      indexUrl: CLOUD_WORKFLOW_INDEX_URL
    }
  };
}

const $ = id => document.getElementById(id);

function currentWorkflow() {
  if (!state.workflows || !Object.keys(state.workflows).length) {
    state.workflows = { [FE_WORKFLOW.id]: clone(FE_WORKFLOW), [SIMPLE_WORKFLOW.id]: clone(SIMPLE_WORKFLOW) };
  }
  if (!state.activeWorkflowId || !state.workflows[state.activeWorkflowId]) {
    state.activeWorkflowId = Object.keys(state.workflows)[0];
  }
  return state.workflows[state.activeWorkflowId];
}

function currentSteps() {
  return currentWorkflow().steps || [];
}

function stepById(id) {
  return currentSteps().find(s => s.id === id);
}

function log(msg) {
  const el = $("log");
  const t = new Date().toLocaleTimeString("vi-VN");
  el.textContent += `[${t}] ${msg}\n`;
  el.scrollTop = el.scrollHeight;
}

function wc(text) {
  const m = (text || "").trim().match(/\S+/g);
  return m ? m.length : 0;
}

function setRunning(value) {
  isRunning = value;
  document.querySelectorAll("#runButtons button, #btnCheck, #btnNewProject").forEach(btn => {
    if (btn) btn.disabled = value;
  });
}

function syncInputs() {
  state.projectCode = $("projectCode").value.trim();
  state.newTitle = $("newTitle").value.trim();
  state.originalScript = $("originalScript").value.trim();
  state.extraNotes = $("extraNotes").value.trim();
  state.totalChapterCount = $("totalChapterCount").value.trim();
  state.nextChapterNumber = Number($("nextChapterNumber").value || 2);
  state.appVersion = EXT_VERSION;
}

function currentOutputValue() {
  return { key: $("outputBox").dataset.outputKey || state.activeOutput, value: $("outputBox").value };
}

function saveVisibleOutput() {
  const { key, value } = currentOutputValue();
  if (!key) return;

  if (key.startsWith("output:")) {
    state.outputs[key.slice(7)] = value;
  } else if (key.startsWith("chapter:")) {
    state.chapters[key.slice(8)] = value;
  }
}

async function saveRaw() {
  state.appVersion = EXT_VERSION;
  await chrome.storage.local.set({ [STORAGE_KEY]: state });
}

async function saveAllFromUI() {
  syncInputs();
  saveVisibleOutput();
  await saveRaw();
}

async function loadState() {
  const keys = [STORAGE_KEY, ...OLD_KEYS];
  const data = await chrome.storage.local.get(keys);
  const loaded = data[STORAGE_KEY] || data.kovaContentAssistantV2 || data.kovaProjectV14 || data.kovaProjectV11 || data.kovaProject;

  if (loaded) {
    let workflows = loaded.workflows || null;

    // migrate v2 prompt profiles to workflows
    if (!workflows && loaded.promptProfiles) {
      workflows = {};
      for (const [name, prompts] of Object.entries(loaded.promptProfiles)) {
        const wf = clone(FE_WORKFLOW);
        wf.id = name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "") || "workflow";
        wf.name = name;
        wf.steps.forEach(step => {
          if (prompts[step.id]) step.prompt = prompts[step.id];
          if (step.id === "nextChapter" && prompts.nextChapter) step.prompt = prompts.nextChapter;
        });
        workflows[wf.id] = wf;
      }
    }

    if (!workflows) {
      workflows = {
        [FE_WORKFLOW.id]: clone(FE_WORKFLOW),
        [SIMPLE_WORKFLOW.id]: clone(SIMPLE_WORKFLOW)
      };
    }

    const active = loaded.activeWorkflowId && workflows[loaded.activeWorkflowId]
      ? loaded.activeWorkflowId
      : Object.keys(workflows)[0];

    state = Object.assign(freshState(workflows, active), loaded);
    state.workflows = workflows;
    state.activeWorkflowId = active;
    state.outputs = Object.assign({}, loaded.outputs || {});
    state.chapters = Object.assign({}, loaded.chapters || {});
    state.extracted = Object.assign({ deXuatMoi: "", seoKeywords: "" }, loaded.extracted || {});
    state.projectConfig = Object.assign(clone(DEFAULT_PROJECT_CONFIG), loaded.projectConfig || {});
    state.cloudSync = Object.assign({
      lastSyncedAt: "",
      lastStatus: "",
      indexUrl: CLOUD_WORKFLOW_INDEX_URL
    }, loaded.cloudSync || {});
    state.appVersion = EXT_VERSION;
  } else {
    state = freshState();
  }

  await saveRaw();
  renderAll();
  log(`Extension v${EXT_VERSION} sẵn sàng. Workflow Pack Manager đã bật.`);
}

function renderAll() {
  $("projectCode").value = state.projectCode || "";
  $("newTitle").value = state.newTitle || "";
  $("originalScript").value = state.originalScript || "";
  $("extraNotes").value = state.extraNotes || "";
  $("totalChapterCount").value = state.totalChapterCount || "";
  $("nextChapterNumber").value = state.nextChapterNumber || 2;

  renderWorkflowSelect();
  renderProjectConfigSummary();
  renderCloudWorkflowStatus();
  renderRunButtons();
  renderTabs();
  renderOutput();
  renderStepSelect();
}


function renderCloudWorkflowStatus() {
  const el = $("cloudWorkflowStatus");
  if (!el) return;

  const sync = state.cloudSync || {};
  const time = sync.lastSyncedAt ? new Date(sync.lastSyncedAt).toLocaleString("vi-VN") : "chưa sync";
  const status = sync.lastStatus || "Chưa sync.";
  el.textContent = `${status} · Lần sync: ${time}`;
}

function normalizeWorkflowFromCloud(raw, fallbackId = "") {
  if (!raw || typeof raw !== "object") throw new Error("Workflow JSON không hợp lệ.");

  const wf = clone(raw);
  wf.id = String(wf.id || fallbackId || wf.name || "").toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_|_$/g, "");

  if (!wf.id) throw new Error("Workflow thiếu id.");
  if (!wf.name) wf.name = wf.id;
  if (!Array.isArray(wf.steps)) throw new Error(`Workflow ${wf.name} thiếu steps[].`);

  // ensure minimal fields
  wf.version = wf.version || "cloud";
  wf.source = "cloud";
  wf.cloudUpdatedAt = new Date().toISOString();

  return wf;
}

async function fetchJsonNoCache(url) {
  const res = await fetch(url + (url.includes("?") ? "&" : "?") + "t=" + Date.now(), { cache: "no-store" });
  if (!res.ok) throw new Error(`Không đọc được ${url}`);
  return await res.json();
}

function resolveWorkflowUrl(item) {
  if (typeof item === "string") {
    if (/^https?:\/\//i.test(item)) return item;
    return CLOUD_WORKFLOW_BASE_URL + item.replace(/^\/+/, "");
  }

  const url = item.url || item.download_url || item.path || item.file;
  if (!url) throw new Error("Workflow item thiếu url/path/file.");

  if (/^https?:\/\//i.test(url)) return url;
  return CLOUD_WORKFLOW_BASE_URL + String(url).replace(/^\/+/, "");
}

async function syncCloudWorkflows() {
  const btn = $("btnSyncCloudWorkflows");
  try {
    if (btn) btn.disabled = true;
    $("cloudWorkflowStatus").textContent = "Đang sync cloud workflows...";

    const index = await fetchJsonNoCache(CLOUD_WORKFLOW_INDEX_URL);
    const items = Array.isArray(index) ? index : (index.workflows || []);
    if (!Array.isArray(items) || !items.length) throw new Error("index.json không có workflows.");

    let added = 0;
    let updated = 0;
    const errors = [];

    for (const item of items) {
      try {
        const url = resolveWorkflowUrl(item);
        const raw = await fetchJsonNoCache(url);
        const fallbackId = typeof item === "object" ? (item.id || item.name || item.file || item.path || "") : item;
        const wf = normalizeWorkflowFromCloud(raw, fallbackId);

        const existed = !!state.workflows[wf.id];
        const existing = state.workflows[wf.id];

        // preserve local project data, but update cloud workflow definition.
        // If user duplicated a workflow locally with a different id, it is not touched.
        state.workflows[wf.id] = Object.assign({}, existing || {}, wf, {
          id: wf.id,
          name: wf.name,
          steps: wf.steps,
          autoReviewSteps: wf.autoReviewSteps || [],
          autoFullScript: wf.autoFullScript || null,
          export: wf.export || { mode: "all_outputs_clean" },
          source: "cloud",
          cloudUrl: url,
          cloudVersion: wf.version || "",
          cloudUpdatedAt: wf.cloudUpdatedAt
        });

        if (existed) updated += 1;
        else added += 1;
      } catch (e) {
        errors.push(e.message);
      }
    }

    state.cloudSync = {
      lastSyncedAt: new Date().toISOString(),
      lastStatus: `Sync xong: thêm ${added}, cập nhật ${updated}${errors.length ? ", lỗi " + errors.length : ""}`,
      indexUrl: CLOUD_WORKFLOW_INDEX_URL,
      errors
    };

    await saveRaw();
    renderAll();
    log(state.cloudSync.lastStatus);
    if (errors.length) log("Cloud sync errors: " + errors.join(" | "));
  } catch (e) {
    state.cloudSync = Object.assign(state.cloudSync || {}, {
      lastSyncedAt: new Date().toISOString(),
      lastStatus: "Sync lỗi: " + e.message
    });
    await saveRaw();
    renderCloudWorkflowStatus();
    log("LỖI Cloud Sync: " + e.message);
    alert(e.message);
  } finally {
    if (btn) btn.disabled = false;
  }
}

function renderWorkflowSelect() {
  const sel = $("workflowSelect");
  sel.innerHTML = "";
  Object.values(state.workflows || {}).forEach(wf => {
    const opt = document.createElement("option");
    opt.value = wf.id;
    opt.textContent = wf.name || wf.id;
    sel.appendChild(opt);
  });
  sel.value = state.activeWorkflowId;
}

function renderProjectConfigSummary() {
  const el = $("projectConfigSummary");
  if (!el) return;
  const cfg = state.projectConfig || DEFAULT_PROJECT_CONFIG;
  el.textContent = `${cfg.projectName || "Project"} · ${cfg.language || ""} · ${cfg.targetLength || ""}`;
}

function openProjectConfigEditor() {
  $("projectConfigBox").value = JSON.stringify(state.projectConfig || DEFAULT_PROJECT_CONFIG, null, 2);
  $("projectConfigEditor").classList.remove("hidden");
}

async function saveProjectConfigFromEditor() {
  try {
    const cfg = JSON.parse($("projectConfigBox").value);
    state.projectConfig = Object.assign(clone(DEFAULT_PROJECT_CONFIG), cfg);
    await saveRaw();
    renderProjectConfigSummary();
    log("Đã lưu Project Config: " + (state.projectConfig.projectName || "Project"));
  } catch (e) {
    alert("Project Config JSON không hợp lệ: " + e.message);
  }
}

async function resetProjectConfig() {
  if (!confirm("Reset Project Config về mặc định FE Stories?")) return;
  state.projectConfig = clone(DEFAULT_PROJECT_CONFIG);
  await saveRaw();
  renderAll();
  log("Đã reset Project Config.");
}

function formatList(value) {
  if (Array.isArray(value)) return value.map(x => "- " + x).join("\\n");
  return String(value || "");
}

function projectConfigText() {
  const cfg = state.projectConfig || DEFAULT_PROJECT_CONFIG;
  return JSON.stringify(cfg, null, 2);
}

function renderRunButtons() {
  const box = $("runButtons");
  box.innerHTML = "";

  addRunButton(box, "Auto Review", "primary", () => autoReview());
  addRunButton(box, "Auto Full", "primary2", () => autoFull());

  currentSteps().forEach(step => {
    addRunButton(box, step.name || step.id, "", () => runStep(step.id));
  });

  addRunButton(box, "Dừng auto", "light", () => {
    stopRequested = true;
    log("Đã yêu cầu dừng auto sau tác vụ hiện tại.");
  });
}

function addRunButton(container, text, cls, onclick) {
  const b = document.createElement("button");
  b.type = "button";
  b.textContent = text;
  if (cls) b.className = cls;
  b.onclick = onclick;
  container.appendChild(b);
}

function renderTabs() {
  const tabs = $("tabs");
  tabs.innerHTML = "";

  const wf = currentWorkflow();
  addTab(tabs, "workflow:" + wf.id, "Workflow");

  currentSteps().forEach(step => {
    const key = step.saveTo === "chapter"
      ? `chapter:${resolveChapterNumber(step)}`
      : `output:${step.outputKey || step.id}`;
    addTab(tabs, key, step.name || step.id);
  });

  Object.keys(state.chapters || {}).map(Number).sort((a,b)=>a-b).forEach(n => {
    addTab(tabs, `chapter:${n}`, `Ch.${n}`);
  });
}

function addTab(container, key, name) {
  const b = document.createElement("button");
  b.type = "button";
  b.className = "tab" + (state.activeOutput === key ? " active" : "");
  b.textContent = name;
  b.onclick = async e => {
    e.preventDefault();
    e.stopPropagation();
    syncInputs();
    saveVisibleOutput();
    state.activeOutput = key;
    await saveRaw();
    renderTabs();
    renderOutput();
  };
  container.appendChild(b);
}

function getOutputText(key) {
  if (!key) return "";
  if (key.startsWith("output:")) return state.outputs[key.slice(7)] || "";
  if (key.startsWith("chapter:")) return state.chapters[key.slice(8)] || "";
  if (key.startsWith("workflow:")) return JSON.stringify(currentWorkflow(), null, 2);
  return "";
}

function getOutputTitle(key) {
  if (!key) return "Output";
  if (key.startsWith("output:")) {
    const id = key.slice(7);
    const step = currentSteps().find(s => (s.outputKey || s.id) === id);
    return step?.name || id;
  }
  if (key.startsWith("chapter:")) return "Chương " + key.slice(8);
  if (key.startsWith("workflow:")) return "Workflow JSON";
  return key;
}

function renderOutput() {
  const key = state.activeOutput || ("workflow:" + currentWorkflow().id);
  const text = getOutputText(key);
  $("activeTitle").textContent = getOutputTitle(key);
  $("outputBox").dataset.outputKey = key;
  $("outputBox").value = text;
  $("wordCount").textContent = `${wc(text)} từ`;
}

function renderStepSelect() {
  const sel = $("stepSelect");
  sel.innerHTML = "";
  currentSteps().forEach(step => {
    const opt = document.createElement("option");
    opt.value = step.id;
    opt.textContent = step.name || step.id;
    sel.appendChild(opt);
  });
  const first = currentSteps()[0];
  if (first) {
    sel.value = first.id;
    $("promptBox").value = first.prompt || "";
  }
}

function normalize(text) {
  return (text || "").replace(/\r/g, "\n").replace(/\u00A0/g, " ").replace(/[ \t]+/g, " ");
}

function lineIndex(lines, patterns, from = 0) {
  for (let i = from; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    if (patterns.some(p => p.test(line))) return i;
  }
  return -1;
}

function blockByHeading(text, startPatterns, endPatterns) {
  const lines = normalize(text).split("\n");
  const s = lineIndex(lines, startPatterns);
  if (s === -1) return "";
  let e = lines.length;
  for (let i = s + 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    if (endPatterns.some(p => p.test(line))) {
      e = i;
      break;
    }
  }
  return lines.slice(s + 1, e).join("\n").trim();
}

function extractFromAnalysis() {
  const text = state.outputs.analysis || "";
  const deXuat = blockByHeading(
    text,
    [/^(?:#{1,6}\s*)?(?:\*\*)?\s*(?:iii|3|ba)?\s*[\.\)]?\s*điểm\s*yếu\s*(?:và|&)\s*cách\s*cải\s*thiện\s*(?:\*\*)?\s*:?$/i],
    [/^(?:#{1,6}\s*)?(?:\*\*)?\s*(?:iv|4|bốn)?\s*[\.\)]?\s*seo\s*keywords?\s*(?:\*\*)?\s*:?$/i, /kết\s*luận/i]
  );
  const seo = blockByHeading(
    text,
    [/^(?:#{1,6}\s*)?(?:\*\*)?\s*(?:iv|4|bốn)?\s*[\.\)]?\s*seo\s*keywords?\s*(?:\*\*)?\s*:?$/i],
    [/^(?:#{1,6}\s*)?(?:\*\*)?\s*(?:v|5|năm)?\s*[\.\)]?\s*kết\s*luận\s*(?:\*\*)?\s*:?$/i]
  );
  state.extracted.deXuatMoi = deXuat || "[Không tách được mục Điểm yếu và cách cải thiện từ B1.]";
  state.extracted.seoKeywords = seo || "[Không tách được mục SEO keywords từ B1.]";
  return state.extracted;
}

function parseChapterCount(skeleton) {
  const text = skeleton || "";
  const patterns = [
    /Suggested\s+Chapter\s+Count\s*[:：\-]?\s*(\d{1,2})/i,
    /Suggested\s+Chapters?\s*[:：\-]?\s*(\d{1,2})/i,
    /Chapter\s+Count\s*[:：\-]?\s*(\d{1,2})/i,
    /Số\s+chương\s+(?:đề\s+xuất|gợi\s+ý|suggested)?\s*[:：\-]?\s*(\d{1,2})/i,
    /Tổng\s+số\s+chương\s*[:：\-]?\s*(\d{1,2})/i
  ];
  for (const p of patterns) {
    const m = text.match(p);
    if (m && Number(m[1]) >= 2) return Number(m[1]);
  }
  const nums = [...text.matchAll(/(?:^|\n)\s*(?:#{1,6}\s*)?(?:Chapter|Chương)\s+(\d{1,2})\b/gi)].map(x => Number(x[1]));
  return nums.length ? Math.max(...nums) : null;
}

function getTotalChapterCount() {
  const manual = Number(state.totalChapterCount || $("totalChapterCount").value || 0);
  if (manual && manual >= 2) return manual;
  const skeleton = state.outputs.skeleton || state.outputs.outline || "";
  const parsed = parseChapterCount(skeleton);
  if (parsed && parsed >= 2) {
    state.totalChapterCount = String(parsed);
    $("totalChapterCount").value = String(parsed);
    return parsed;
  }
  return null;
}

function resolveChapterNumber(step, fallbackNumber) {
  const raw = step.chapterNumber;
  if (raw === "{{CHAPTER_COUNT}}") return getTotalChapterCount() || "final";
  if (raw === "{{CHAPTER_NUMBER}}") return fallbackNumber || state.nextChapterNumber || 2;
  if (raw === undefined || raw === null || raw === "") return fallbackNumber || state.nextChapterNumber || 1;
  return Number(raw) || raw;
}

function buildFullScriptOrdered() {
  const nums = Object.keys(state.chapters || {}).map(Number).filter(Number.isFinite).sort((a,b)=>a-b);
  return nums.map(n => state.chapters[String(n)]).filter(Boolean).join("\n\n");
}

function cleanChapterContent(raw) {
  let text = String(raw || "").replace(/\r/g, "\n").trim();
  text = text.replace(/^```(?:text|markdown|md)?\s*/i, "").replace(/```\s*$/i, "").trim();
  let lines = text.split("\n");
  while (lines.length && !lines[0].trim()) lines.shift();
  const junk = [
    /^\s*(?:chapter|chương)\s*\d{1,2}\b(?:\s*[-–—:.)].*)?$/i,
    /^\s*\d{1,2}\s*[\.)]?\s*$/i,
    /^\s*(?:here\s+is|here's)\s+(?:the\s+)?(?:chapter|next\s+chapter|final\s+chapter).*$/i,
    /^\s*(?:sure|certainly)[,.]?\s*(?:here\s+is|here's).*$/i,
    /^\s*(?:opening\s+hook|hook|chapter\s+title)\s*[:.]?\s*$/i,
    /^\s*title\s*[:：].*$/i
  ];
  let removed = true;
  while (removed && lines.length) {
    removed = false;
    const first = lines[0].trim();
    if (!first || junk.some(p => p.test(first))) {
      lines.shift();
      removed = true;
    }
  }
  return lines.join("\n").replace(/\n{3,}/g, "\n\n").trim();
}

function buildCleanScript() {
  const nums = Object.keys(state.chapters || {}).map(Number).filter(Number.isFinite).sort((a,b)=>a-b);
  return nums.map(n => cleanChapterContent(state.chapters[String(n)])).filter(Boolean).join("\n\n");
}

function renderTemplate(step, chapterNumber) {
  extractFromAnalysis();
  const cfg = state.projectConfig || DEFAULT_PROJECT_CONFIG;
  const vars = {
    NEW_TITLE: state.newTitle || "",
    ORIGINAL_SCRIPT: state.originalScript || "",
    EXTRA_NOTES: state.extraNotes || "",
    PROJECT_NAME: cfg.projectName || "",
    LANGUAGE: cfg.language || "",
    CHANNEL_DNA: cfg.channelDNA || "",
    STORY_WORLD: cfg.storyWorld || "",
    TARGET_LENGTH: cfg.targetLength || "",
    CHAPTER_LENGTH: cfg.chapterLength || "",
    STYLE_RULES: formatList(cfg.styleRules),
    FORBIDDEN_RULES: formatList(cfg.forbiddenRules),
    PROJECT_CONFIG: projectConfigText(),
    ANALYSIS: state.outputs.analysis || "",
    SKELETON: state.outputs.skeleton || "",
    SUMMARY: state.outputs.summary || "",
    DE_XUAT_MOI: state.extracted.deXuatMoi || "",
    SEO_KEYWORDS: state.extracted.seoKeywords || "",
    CHAPTERS: buildFullScriptOrdered(),
    CHAPTER_NUMBER: chapterNumber || state.nextChapterNumber || 2,
    CHAPTER_COUNT: getTotalChapterCount() || "",
  };

  let prompt = step.prompt || "";
  prompt = prompt.replace(/\{\{OUTPUT:([a-zA-Z0-9_-]+)\}\}/g, (_, id) => state.outputs[id] || "");
  prompt = prompt.replace(/\{\{CHAPTER:([0-9]+)\}\}/g, (_, n) => state.chapters[n] || "");
  prompt = prompt.replace(/\{\{CONFIG:([a-zA-Z0-9_.-]+)\}\}/g, (_, key) => {
    const value = key.split(".").reduce((acc, part) => acc && acc[part], cfg);
    return Array.isArray(value) ? formatList(value) : (value ?? "");
  });
  prompt = prompt.replace(/\{\{([A-Z_]+)\}\}/g, (_, name) => vars[name] ?? "");
  return prompt;
}

async function getChatGPTTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const active = tabs[0];
  if (active && /https:\/\/(chatgpt\.com|chat\.openai\.com)\//.test(active.url || "")) return active;
  const all = await chrome.tabs.query({ url: ["https://chatgpt.com/*", "https://chat.openai.com/*"] });
  if (all.length) return all[0];
  throw new Error("Không tìm thấy tab ChatGPT. Hãy mở đúng Project/đoạn chat trên chatgpt.com trước.");
}

async function ensureContentScript(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "KOVA_PING" });
  } catch {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
  }
}

async function pingChatGPT() {
  const tab = await getChatGPTTab();
  await ensureContentScript(tab.id);
  return chrome.tabs.sendMessage(tab.id, { type: "KOVA_PING" });
}

async function sendToChatGPT(prompt) {
  const tab = await getChatGPTTab();
  await ensureContentScript(tab.id);
  await chrome.tabs.update(tab.id, { active: true });
  const res = await chrome.tabs.sendMessage(tab.id, {
    type: "KOVA_RUN_PROMPT",
    prompt,
    options: { timeoutSec: 900, stableSec: 14 }
  });
  if (!res || !res.ok) throw new Error(res?.error || "Không nhận được output từ ChatGPT.");
  return res.answer || "";
}

async function runStep(stepId, opts = {}) {
  const step = stepById(stepId);
  if (!step) throw new Error("Không tìm thấy bước: " + stepId);

  if (!opts.internal && isRunning) {
    log("Đang chạy automation khác.");
    return;
  }
  if (!opts.internal) setRunning(true);

  try {
    syncInputs();
    await saveRaw();

    if (!state.newTitle && !state.originalScript) {
      alert("Bạn cần nhập tiêu đề/chủ đề hoặc input gốc trước.");
      return;
    }

    const chapterNo = opts.chapterNumber || resolveChapterNumber(step, opts.chapterNumber);
    const answer = await sendToChatGPT(renderTemplate(step, chapterNo));

    if (step.saveTo === "chapter") {
      const n = resolveChapterNumber(step, opts.chapterNumber);
      if (!n || n === "final") throw new Error("Không xác định được số chương. Hãy nhập Tổng số chương.");
      state.chapters[String(n)] = answer;
      state.nextChapterNumber = Number(n) + 1;
      state.activeOutput = `chapter:${n}`;
    } else {
      const key = step.outputKey || step.id;
      state.outputs[key] = answer;
      if (key === "analysis") extractFromAnalysis();
      if (key === "skeleton") {
        const t = parseChapterCount(answer);
        if (t) state.totalChapterCount = String(t);
      }
      state.activeOutput = `output:${key}`;
    }

    await saveRaw();
    renderAll();
    log(`Đã lưu ${step.name || step.id}: ${wc(answer)} từ.`);
  } finally {
    if (!opts.internal) setRunning(false);
  }
}

async function autoReview() {
  if (isRunning) return;
  setRunning(true);
  try {
    const steps = currentWorkflow().autoReviewSteps || [];
    if (!steps.length) {
      alert("Workflow này chưa cấu hình autoReviewSteps.");
      return;
    }
    for (const stepId of steps) {
      if (stopRequested) break;
      await runStep(stepId, { internal: true });
      await new Promise(r => setTimeout(r, 1200));
    }
    log("Đã chạy xong Auto Review. Dừng để bạn duyệt.");
  } catch (e) {
    log("LỖI Auto Review: " + e.message);
    alert(e.message);
  } finally {
    setRunning(false);
    stopRequested = false;
  }
}

async function autoFull() {
  if (isRunning) return;
  setRunning(true);

  try {
    const cfg = currentWorkflow().autoFullScript;
    if (!cfg) {
      alert("Workflow này chưa cấu hình autoFullScript.");
      return;
    }

    syncInputs();
    await saveRaw();

    const total = getTotalChapterCount();
    if (!total || total < 2) {
      alert("Không đọc được Tổng số chương. Hãy nhập tay trước khi Auto Full.");
      return;
    }

    if (Object.keys(state.chapters || {}).length) {
      const ok = confirm("Đã có chương cũ. Auto Full sẽ viết lại từ chương 1 và ghi đè chương cũ. Tiếp tục?");
      if (!ok) return;
    }

    state.chapters = {};
    state.nextChapterNumber = 2;
    stopRequested = false;
    await saveRaw();
    renderAll();

    log(`Auto Full: Chương 1 → Chương ${total}. Mỗi chương gửi prompt riêng.`);

    await runStep(cfg.chapter1Step, { internal: true });

    for (let n = 2; n <= total - 1; n++) {
      if (stopRequested) break;
      state.nextChapterNumber = n;
      $("nextChapterNumber").value = n;
      await saveRaw();
      await runStep(cfg.loopStep, { chapterNumber: n, internal: true });
      await new Promise(r => setTimeout(r, 1800));
    }

    if (!stopRequested) {
      await runStep(cfg.finalStep, { internal: true });
      log("Đã Auto Full xong. Có thể Export TXT.");
    }
  } catch (e) {
    log("LỖI Auto Full: " + e.message);
    alert(e.message);
  } finally {
    setRunning(false);
    stopRequested = false;
  }
}

async function checkTab() {
  try {
    const res = await pingChatGPT();
    $("statusDot").classList.toggle("ok", !!res.ok);
    $("status").textContent = res.ok
      ? `Đã kết nối: ${res.title || res.url}. Composer: ${res.hasComposer ? "OK" : "chưa thấy"} · Send: ${res.hasSendButton ? "OK" : "fallback Enter"}`
      : "Chưa kết nối.";
    log("Kiểm tra ChatGPT: " + JSON.stringify(res));
  } catch (e) {
    $("statusDot").classList.remove("ok");
    $("status").textContent = e.message;
    log("LỖI kiểm tra: " + e.message);
  }
}

function compareVersions(a, b) {
  const pa = String(a || "0").split(".").map(x => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map(x => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    if ((pa[i] || 0) > (pb[i] || 0)) return 1;
    if ((pa[i] || 0) < (pb[i] || 0)) return -1;
  }
  return 0;
}

function setUpdateUI(message, hasUpdate = false, info = null) {
  $("updateStatus").textContent = message;
  $("updateActions").classList.toggle("hidden", !hasUpdate);
  $("updateGuide").classList.toggle("hidden", !hasUpdate);
  if (hasUpdate && info) {
    $("btnDownloadUpdate").dataset.url = info.download_url || "";
    $("btnOpenRepo").dataset.url = info.repo_url || UPDATE_REPO_URL;
  }
}

async function checkForUpdates(silent = false) {
  try {
    setUpdateUI(`Đang kiểm tra update... Phiên bản hiện tại: v${EXT_VERSION}`);
    const res = await fetch(UPDATE_INFO_URL + "?t=" + Date.now(), { cache: "no-store" });
    if (!res.ok) throw new Error("Không đọc được version.json từ GitHub.");
    const info = await res.json();
    const latest = String(info.version || "").trim();
    if (!latest) throw new Error("version.json thiếu version.");
    if (compareVersions(EXT_VERSION, latest) < 0) {
      setUpdateUI(`Có bản mới: v${latest}${info.notes ? " · " + info.notes : ""}. Hiện tại: v${EXT_VERSION}`, true, info);
      log(`Có bản cập nhật mới: v${latest}`);
      return;
    }
    setUpdateUI(`Đang dùng bản mới nhất: v${EXT_VERSION}`);
    if (!silent) log("Extension đang là bản mới nhất.");
  } catch (e) {
    setUpdateUI(`Không kiểm tra được update: ${e.message}`);
    if (!silent) log("LỖI kiểm tra update: " + e.message);
  }
}

function downloadBlob(blob, name) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}

async function exportJSON() {
  await saveAllFromUI();
  downloadBlob(new Blob([JSON.stringify(state, null, 2)], { type: "application/json" }), `${state.projectCode || "kova-project"}.json`);
}

async function exportTXT() {
  await saveAllFromUI();
  const wf = currentWorkflow();
  let content = "";

  if (wf.export?.mode === "chapters_only_clean") {
    content = buildCleanScript();
  } else if (wf.export?.mode === "chapters_only") {
    content = buildFullScriptOrdered();
  } else {
    const parts = [];
    for (const step of currentSteps()) {
      if (step.saveTo === "outputs") {
        const key = step.outputKey || step.id;
        if (state.outputs[key]) parts.push(state.outputs[key]);
      }
    }
    content = parts.join("\n\n");
  }

  content = content.trim();
  if (!content) {
    alert("Chưa có nội dung để export.");
    return;
  }
  downloadBlob(new Blob([content], { type: "text/plain;charset=utf-8" }), `${state.projectCode || "kova-content"}.txt`);
}

function importJSONFile(file) {
  const reader = new FileReader();
  reader.onload = async () => {
    try {
      const imported = JSON.parse(reader.result);
      state = Object.assign(freshState(), imported);
      if (!state.workflows) state.workflows = freshState().workflows;
      await saveRaw();
      renderAll();
      log("Import thành công.");
    } catch {
      alert("File JSON không hợp lệ.");
    }
  };
  reader.readAsText(file);
}

function newProject() {
  if (!confirm("Tạo project mới? Workflow hiện có sẽ được giữ.")) return;
  const workflows = state.workflows;
  const active = state.activeWorkflowId;
  state = freshState(workflows, active);
  saveRaw().then(renderAll);
}

function refreshWorkflowJsonEditor() {
  $("workflowJsonBox").value = JSON.stringify(buildWorkflowPack(currentWorkflow()), null, 2);
}


function workflowFileName(wf) {
  const base = String(wf.name || wf.id || "workflow")
    .trim()
    .replace(/[^\w\-]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
  return `${base || "workflow"}.json`;
}

function buildWorkflowPack(wf = currentWorkflow()) {
  // Workflow Pack = workflow definition + default projectConfig template.
  // It is clean enough to upload directly to GitHub workflows/.
  const pack = clone(wf);
  pack.version = pack.version || "1.0";
  pack.updatedAt = new Date().toISOString();
  pack.projectConfig = clone(state.projectConfig || DEFAULT_PROJECT_CONFIG);

  // Runtime-only metadata should not be required in cloud workflow files.
  delete pack.cloudUpdatedAt;

  return pack;
}

function applyWorkflowPack(pack, options = {}) {
  if (!pack || typeof pack !== "object") throw new Error("Workflow pack không hợp lệ.");
  if (!pack.id || !pack.name || !Array.isArray(pack.steps)) {
    throw new Error("Workflow pack cần có id, name, steps[].");
  }

  const wf = clone(pack);
  const cfg = wf.projectConfig ? clone(wf.projectConfig) : null;

  delete wf.projectConfig;

  wf.updatedAt = wf.updatedAt || new Date().toISOString();
  wf.source = options.source || wf.source || "local";

  state.workflows[wf.id] = wf;
  state.activeWorkflowId = wf.id;
  state.activeOutput = "workflow:" + wf.id;

  if (cfg && options.applyProjectConfig !== false) {
    state.projectConfig = Object.assign(clone(DEFAULT_PROJECT_CONFIG), cfg);
  }

  return wf;
}

async function saveCurrentWorkflowPack() {
  syncInputs();
  saveVisibleOutput();

  const wf = currentWorkflow();
  wf.updatedAt = new Date().toISOString();
  wf.projectConfig = clone(state.projectConfig || DEFAULT_PROJECT_CONFIG);

  state.workflows[wf.id] = wf;
  await saveRaw();

  const steps = Array.isArray(wf.steps) ? wf.steps.length : 0;
  const msg = `Đã lưu toàn bộ workflow: ${wf.name || wf.id} · ${steps} bước · ${new Date(wf.updatedAt).toLocaleString("vi-VN")}`;
  $("workflowPackStatus").textContent = msg;
  log(msg);
}

async function exportCurrentWorkflowPack() {
  await saveCurrentWorkflowPack();

  const pack = buildWorkflowPack(currentWorkflow());
  const blob = new Blob([JSON.stringify(pack, null, 2)], { type: "application/json;charset=utf-8" });
  downloadBlob(blob, workflowFileName(pack));
  log("Đã export Workflow JSON: " + workflowFileName(pack));
}

function importWorkflowPackFile(file) {
  const reader = new FileReader();
  reader.onload = async () => {
    try {
      const pack = JSON.parse(reader.result);
      applyWorkflowPack(pack, { source: "imported", applyProjectConfig: true });
      await saveRaw();
      renderAll();
      log("Import Workflow Pack thành công: " + currentWorkflow().name);
    } catch (e) {
      alert("Workflow JSON không hợp lệ: " + e.message);
    }
  };
  reader.readAsText(file);
}

async function duplicateWorkflowForProject() {
  const wf = currentWorkflow();
  const name = prompt("Tên dự án/workflow mới:", (state.projectConfig?.projectName || wf.name || "New Project") + " Copy");
  if (!name) return;

  const id = name.toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_|_$/g, "") || "workflow";

  if (state.workflows[id]) {
    alert("Workflow này đã tồn tại.");
    return;
  }

  const newWf = clone(wf);
  newWf.id = id;
  newWf.name = name;
  newWf.source = "local";
  newWf.updatedAt = new Date().toISOString();

  state.workflows[id] = newWf;
  state.activeWorkflowId = id;
  state.activeOutput = "workflow:" + id;

  state.projectConfig = Object.assign(clone(DEFAULT_PROJECT_CONFIG), state.projectConfig || {}, {
    projectName: name
  });

  await saveRaw();
  renderAll();
  log("Đã nhân bản workflow cho dự án mới: " + name);
}

async function saveCurrentStepPrompt() {
  const step = stepById($("stepSelect").value);
  if (!step) return;
  step.prompt = $("promptBox").value;
  currentWorkflow().updatedAt = new Date().toISOString();
  await saveRaw();
  log("Đã lưu prompt cho bước: " + (step.name || step.id));
}

async function saveStepPromptAndWorkflow() {
  await saveCurrentStepPrompt();
  await saveCurrentWorkflowPack();
}

chrome.runtime.onMessage.addListener(message => {
  if (message?.type === "KOVA_PROGRESS") {
    if (message.status) log(message.status);
    if (message.words) log(`ChatGPT đang trả lời... ${message.words} từ`);
  }
});

document.addEventListener("input", async e => {
  if (["projectCode", "newTitle", "originalScript", "extraNotes", "nextChapterNumber", "totalChapterCount"].includes(e.target.id)) {
    syncInputs();
    await saveRaw();
  }
  if (e.target.id === "outputBox") {
    $("wordCount").textContent = `${wc($("outputBox").value)} từ`;
    saveVisibleOutput();
    await saveRaw();
  }
});

document.addEventListener("DOMContentLoaded", async () => {
  await loadState();

  $("outputBox").addEventListener("click", e => e.stopPropagation());

  $("btnCheck").onclick = checkTab;
  $("btnNewProject").onclick = newProject;
  $("btnSaveInputs").onclick = async () => { await saveAllFromUI(); log("Đã lưu input/output hiện tại."); };
  $("btnExportJson").onclick = exportJSON;
  $("btnImportJson").onclick = () => $("importFile").click();
  $("importFile").onchange = e => e.target.files[0] && importJSONFile(e.target.files[0]);

  $("btnCheckUpdate").onclick = () => checkForUpdates(false);
  $("btnDownloadUpdate").onclick = () => {
    const url = $("btnDownloadUpdate").dataset.url;
    if (!url) return alert("version.json chưa có download_url.");
    chrome.tabs.create({ url });
  };
  $("btnOpenRepo").onclick = () => chrome.tabs.create({ url: $("btnOpenRepo").dataset.url || UPDATE_REPO_URL });
  setTimeout(() => checkForUpdates(true), 1200);

  $("btnSyncCloudWorkflows").onclick = syncCloudWorkflows;
  $("btnOpenWorkflowIndex").onclick = () => chrome.tabs.create({ url: CLOUD_WORKFLOW_INDEX_URL });

  $("workflowSelect").onchange = async () => {
    syncInputs();
    saveVisibleOutput();
    state.activeWorkflowId = $("workflowSelect").value;
    state.activeOutput = "workflow:" + state.activeWorkflowId;
    await saveRaw();
    renderAll();
    log("Đã chuyển workflow: " + currentWorkflow().name);
  };

  $("btnNewWorkflow").onclick = async () => {
    const name = prompt("Tên workflow mới:");
    if (!name) return;
    const id = name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "") || "workflow";
    if (state.workflows[id]) return alert("Workflow này đã tồn tại.");
    const wf = clone(SIMPLE_WORKFLOW);
    wf.id = id;
    wf.name = name;
    state.workflows[id] = wf;
    state.activeWorkflowId = id;
    state.activeOutput = "workflow:" + id;
    await saveRaw();
    renderAll();
    log("Đã tạo workflow mới: " + name);
  };

  $("btnDuplicateWorkflow").onclick = async () => {
    const current = currentWorkflow();
    const name = prompt("Tên workflow nhân bản:", current.name + " Copy");
    if (!name) return;
    const id = name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "") || "workflow";
    if (state.workflows[id]) return alert("Workflow này đã tồn tại.");
    const wf = clone(current);
    wf.id = id;
    wf.name = name;
    state.workflows[id] = wf;
    state.activeWorkflowId = id;
    state.activeOutput = "workflow:" + id;
    await saveRaw();
    renderAll();
    log("Đã nhân bản workflow: " + name);
  };

  $("btnDeleteWorkflow").onclick = async () => {
    const ids = Object.keys(state.workflows);
    if (ids.length <= 1) return alert("Cần giữ ít nhất 1 workflow.");
    const wf = currentWorkflow();
    if (!confirm("Xóa workflow: " + wf.name + "?")) return;
    delete state.workflows[wf.id];
    state.activeWorkflowId = Object.keys(state.workflows)[0];
    state.activeOutput = "workflow:" + state.activeWorkflowId;
    await saveRaw();
    renderAll();
  };

  $("btnEditWorkflow").onclick = () => {
    refreshWorkflowJsonEditor();
    $("workflowEditor").classList.remove("hidden");
  };
  $("btnCloseWorkflowEditor").onclick = () => $("workflowEditor").classList.add("hidden");
  $("btnSaveWorkflowJson").onclick = async () => {
    try {
      const wf = JSON.parse($("workflowJsonBox").value);
      if (!wf.id || !wf.name || !Array.isArray(wf.steps)) throw new Error("Workflow cần có id, name, steps[]");
      applyWorkflowPack(wf, { source: wf.source || "local", applyProjectConfig: true });
      await saveRaw();
      renderAll();
      log("Đã lưu Workflow JSON/Pack: " + wf.name);
    } catch (e) {
      alert("Workflow JSON không hợp lệ: " + e.message);
    }
  };
  $("btnResetWorkflow").onclick = async () => {
    if (!confirm("Reset workflow hiện tại về FE mặc định?")) return;
    const wf = clone(FE_WORKFLOW);
    state.workflows[wf.id] = wf;
    state.activeWorkflowId = wf.id;
    await saveRaw();
    renderAll();
  };

  $("btnEditProjectConfig").onclick = openProjectConfigEditor;
  $("btnCloseProjectConfig").onclick = () => $("projectConfigEditor").classList.add("hidden");
  $("btnSaveProjectConfig").onclick = saveProjectConfigFromEditor;
  $("btnResetProjectConfig").onclick = resetProjectConfig;

  $("btnSaveWorkflowPack").onclick = saveCurrentWorkflowPack;
  $("btnExportWorkflowPack").onclick = exportCurrentWorkflowPack;
  $("btnImportWorkflowPack").onclick = () => $("workflowImportFile").click();
  $("workflowImportFile").onchange = e => e.target.files[0] && importWorkflowPackFile(e.target.files[0]);
  $("btnDuplicateForProject").onclick = duplicateWorkflowForProject;

  $("stepSelect").onchange = () => {
    const step = stepById($("stepSelect").value);
    $("promptBox").value = step?.prompt || "";
  };
  $("btnPromptEditor").onclick = () => $("promptEditor").classList.toggle("hidden");
  $("btnClosePromptEditor").onclick = () => $("promptEditor").classList.add("hidden");
  $("btnSaveStepPrompt").onclick = saveCurrentStepPrompt;
  $("btnSavePromptAndWorkflow").onclick = saveStepPromptAndWorkflow;

  $("btnSaveOutput").onclick = async () => { await saveAllFromUI(); log("Đã lưu output."); };
  $("btnCopyOutput").onclick = async () => { await navigator.clipboard.writeText($("outputBox").value); log("Đã copy output."); };
  $("btnExportTxt").onclick = exportTXT;
});
