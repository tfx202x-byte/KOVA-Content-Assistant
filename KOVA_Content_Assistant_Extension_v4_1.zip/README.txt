KOVA Content Assistant Extension v4.1
=====================================

Bản v4.1 fix lỗi treo UI của v4.0 và chuyển sang mô hình bảo mật hơn bằng License Key.

Điểm quan trọng
---------------
Không dùng username dễ đoán như tung/content01 nữa.

Dùng license key khó đoán, ví dụ:
KOVA-FE-7K9Q-2M4X
KOVA-HT-9P2A-6Q8L
KOVA-ALL-TUNG-93KD-71QP

Extension gọi:
https://kova-workflow-api.tfx202x.workers.dev/check?key=LICENSE
https://kova-workflow-api.tfx202x.workers.dev/workflows?key=LICENSE

KV cần đổi từ:
user:tung

sang:
license:KOVA-ALL-TUNG-93KD-71QP

Value mẫu:
{
  "name": "Tùng",
  "workflows": ["FE-Stories", "HT-Stories", "VH-Stories"],
  "active": true,
  "expires": "2027-12-31"
}

Lưu ý bảo mật
-------------
- License key nằm trong máy người dùng, nên không phải bí mật tuyệt đối.
- Nhưng key khó đoán + có thể thu hồi/gia hạn trong KV.
- Không dùng key kiểu content01/content02 vì quá dễ đoán.
- Không phát workflow JSON thủ công nếu muốn giữ quyền kiểm soát.

Worker cần dùng bản code v4.1 hỗ trợ key=...
