KOVA Content Assistant Extension v3.4
=====================================

Bản v3.4 là bản tối giản chuẩn theo hướng Prompt Workflow.

Đã bỏ hoàn toàn Project Config JSON
-----------------------------------
Vì thực tế DNA kênh, style, độ dài, luật cấm... nên nằm trực tiếp trong prompt của workflow.

Bản này giữ lại các phần cần thiết:
- Workflow Profile
- Prompt Editor từng bước
- Lưu bước + Workflow
- Lưu toàn bộ Workflow
- Export Workflow JSON
- Import Workflow JSON
- Nhân bản cho dự án mới
- Sync Cloud Workflows từ GitHub
- Auto Review
- Auto Full
- Export TXT sạch chỉ lấy content

Cách dùng tối ưu
----------------
1. Chọn workflow gần giống.
2. Bấm Nhân bản cho dự án mới nếu cần.
3. Sửa prompt từng bước nếu cần.
4. Bấm Lưu bước + Workflow hoặc Lưu toàn bộ Workflow.
5. Export Workflow JSON để backup hoặc upload lên GitHub workflows/.
6. Team khác chỉ cần Import Workflow JSON hoặc Sync Cloud Workflows.

Workflow Pack bây giờ rất gọn
-----------------------------
{
  "id": "fe_stories",
  "name": "FE Stories Workflow",
  "version": "1.0",
  "autoReviewSteps": ["analysis", "skeleton", "summary"],
  "export": { "mode": "chapters_only_clean" },
  "autoFullScript": {
    "chapter1Step": "chapter1",
    "loopStep": "nextChapter",
    "finalStep": "finalChapter"
  },
  "steps": [
    {
      "id": "analysis",
      "name": "B1 Phân tích",
      "saveTo": "outputs",
      "outputKey": "analysis",
      "prompt": "..."
    }
  ]
}

Không còn:
- Project Config JSON
- CHANNEL_DNA biến riêng
- STORY_WORLD biến riêng
- STYLE_RULES biến riêng
- FORBIDDEN_RULES biến riêng

Tất cả nội dung đó đưa thẳng vào prompt của workflow.

Update version.json cho v3.4
----------------------------
{
  "version": "3.4.0",
  "notes": "Simplified prompt-based workflow. Removed Project Config JSON.",
  "download_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant/raw/main/KOVA_Content_Assistant_Extension_v3_4.zip",
  "repo_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant"
}
