KOVA Content Assistant Extension v2.4
=====================================

Bản v2.4 xử lý triệt để file TXT export bị lẫn số chương/heading/meta commentary.

Vấn đề
------
Đôi khi ChatGPT vẫn trả output có dạng:

1

Chapter 2

Chapter 3 - The Lie Inside the Living Room

Here is the next chapter...

Các dòng này không nên xuất hiện trong file TXT cuối.

Cách xử lý trong v2.4
--------------------
1. Prompt mặc định đã được chỉnh để yêu cầu GPT:
   - Không ghi số chương.
   - Không ghi tiêu đề chương.
   - Không ghi heading/subheading/meta commentary.
   - Output bắt đầu ngay bằng câu chuyện.

2. Export TXT có thêm lớp làm sạch tự động:
   - Xóa dòng chỉ có số: 1, 2, 3...
   - Xóa dòng Chapter 1 / Chapter 2 / Chương 3...
   - Xóa dòng Chapter 3 - Title...
   - Xóa dòng Here is the next chapter...
   - Xóa markdown fence nếu có.
   - Chỉ ghép phần content thật từ chương 1 đến chương cuối.

Kết quả export
--------------
File TXT cuối chỉ gồm:

Nội dung chương 1

Nội dung chương 2

Nội dung chương 3

...

Nội dung chương cuối

Không có:
- Title
- Summary
- Description
- SEO
- Tags
- Số chương
- Heading chương
- Bình luận của GPT

Update GitHub
-------------
Sau khi upload zip v2.4 lên repo, sửa version.json:

{
  "version": "2.4.0",
  "notes": "Clean content-only TXT export. Removes chapter numbers/headings/meta commentary.",
  "download_url": "https://raw.githubusercontent.com/tfx202x-byte/KOVA-Content-Assistant/main/KOVA_Content_Assistant_Extension_v2_4.zip",
  "repo_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant"
}
