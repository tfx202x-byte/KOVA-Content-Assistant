(() => {
  if (window.__KOVA_CONTENT_ASSISTANT_V2__) return;
  window.__KOVA_CONTENT_ASSISTANT_V2__ = true;

  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  function wordCount(text) {
    return (text || "").trim().split(/\s+/).filter(Boolean).length;
  }

  function isVisible(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    const style = window.getComputedStyle(el);
    return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
  }

  function findComposer() {
    const selectors = [
      '#prompt-textarea',
      '[data-testid="composer-textarea"]',
      'div.ProseMirror[contenteditable="true"]',
      'div[contenteditable="true"][id="prompt-textarea"]',
      'div[contenteditable="true"][data-testid="composer-textarea"]',
      'textarea[data-testid="composer-textarea"]',
      'textarea',
      'div[contenteditable="true"]'
    ];
    for (const sel of selectors) {
      const nodes = Array.from(document.querySelectorAll(sel)).filter(isVisible);
      if (nodes.length) return nodes[nodes.length - 1];
    }
    return null;
  }

  function findSendButton() {
    const selectors = [
      '[data-testid="send-button"]',
      '[data-testid="composer-send-button"]',
      'button[data-testid*="send"]',
      'button[aria-label*="Send"]',
      'button[aria-label*="send"]',
      'button[aria-label*="Gửi"]',
      'button[aria-label*="gửi"]',
      'form button[type="submit"]'
    ];

    for (const sel of selectors) {
      const nodes = Array.from(document.querySelectorAll(sel)).filter(isVisible);
      const enabled = nodes.filter(b => !b.disabled && b.getAttribute("aria-disabled") !== "true");
      if (enabled.length) return enabled[enabled.length - 1];
    }

    // Fallback: choose the nearest enabled button around the composer area, typically the black arrow button.
    const composer = findComposer();
    if (composer) {
      const compRect = composer.getBoundingClientRect();
      const buttons = Array.from(document.querySelectorAll("button")).filter(b => {
        if (!isVisible(b) || b.disabled || b.getAttribute("aria-disabled") === "true") return false;
        const r = b.getBoundingClientRect();
        const nearY = Math.abs((r.top + r.bottom) / 2 - (compRect.top + compRect.bottom) / 2) < 120;
        const rightSide = r.left > compRect.left + compRect.width * 0.55;
        return nearY && rightSide;
      });
      if (buttons.length) return buttons[buttons.length - 1];
    }

    // Last fallback: any enabled visible button with svg/icon near bottom.
    const vh = window.innerHeight;
    const candidates = Array.from(document.querySelectorAll("button")).filter(b => {
      if (!isVisible(b) || b.disabled || b.getAttribute("aria-disabled") === "true") return false;
      const r = b.getBoundingClientRect();
      return r.top > vh * 0.55 && b.querySelector("svg");
    });
    return candidates.length ? candidates[candidates.length - 1] : null;
  }

  function assistantMessages() {
    let nodes = Array.from(document.querySelectorAll('[data-message-author-role="assistant"]'));
    if (nodes.length) return nodes;

    nodes = Array.from(document.querySelectorAll('article')).filter(n => {
      const txt = (n.innerText || "").trim();
      return txt.length > 50 && !txt.includes("ChatGPT có thể mắc lỗi");
    });
    return nodes;
  }

  function getAssistantTextAt(index) {
    const nodes = assistantMessages();
    if (!nodes.length) return "";
    const safeIndex = Math.max(0, Math.min(index, nodes.length - 1));
    return (nodes[safeIndex].innerText || "").trim();
  }

  function getLastAssistantText() {
    const nodes = assistantMessages();
    if (!nodes.length) return "";
    return (nodes[nodes.length - 1].innerText || "").trim();
  }

  function setComposerText(el, text) {
    el.focus();

    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
      el.value = text;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return;
    }

    try {
      const selection = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(el);
      selection.removeAllRanges();
      selection.addRange(range);
      document.execCommand("selectAll", false, null);
      document.execCommand("insertText", false, text);
      el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
    } catch (e) {
      el.textContent = text;
      el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
    }
  }

  async function waitForComposer(timeoutMs = 25000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const composer = findComposer();
      if (composer) return composer;
      await sleep(400);
    }
    throw new Error("Không tìm thấy ô nhập prompt. Hãy mở đúng đoạn chat trong Project và kiểm tra đã đăng nhập ChatGPT.");
  }

  async function waitUntilComposerHasText(timeoutMs = 8000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const composer = findComposer();
      const txt = (composer?.innerText || composer?.value || "").trim();
      if (txt.length > 10) return true;
      await sleep(300);
    }
    return false;
  }

  async function clickSendOrPressEnter() {
    let button = findSendButton();
    if (button) {
      button.click();
      return "button";
    }

    // Fallback: press Enter inside composer.
    const composer = findComposer();
    if (!composer) throw new Error("Không tìm thấy ô nhập prompt để gửi bằng Enter.");
    composer.focus();
    composer.dispatchEvent(new KeyboardEvent("keydown", {
      key: "Enter", code: "Enter", keyCode: 13, which: 13,
      bubbles: true, cancelable: true
    }));
    composer.dispatchEvent(new KeyboardEvent("keyup", {
      key: "Enter", code: "Enter", keyCode: 13, which: 13,
      bubbles: true, cancelable: true
    }));
    return "enter";
  }

  async function sendPrompt(prompt, options = {}) {
    const timeoutSec = options.timeoutSec || 900;
    const stableSec = options.stableSec || 14;

    const beforeCount = assistantMessages().length;
    const composer = await waitForComposer();
    setComposerText(composer, prompt);
    await waitUntilComposerHasText();
    await sleep(700);

    const method = await clickSendOrPressEnter();

    let lastText = "";
    let lastChange = Date.now();
    let sawNew = false;
    let targetIndex = beforeCount;
    const start = Date.now();

    chrome.runtime.sendMessage({ type: "KOVA_PROGRESS", status: `Prompt sent by ${method}` }).catch(() => {});

    while (Date.now() - start < timeoutSec * 1000) {
      await sleep(2000);

      const messages = assistantMessages();
      const count = messages.length;

      if (count > beforeCount) {
        sawNew = true;
        targetIndex = count - 1;
      }

      const text = sawNew ? getAssistantTextAt(targetIndex) : getLastAssistantText();

      if (text !== lastText) {
        lastText = text;
        lastChange = Date.now();
        chrome.runtime.sendMessage({
          type: "KOVA_PROGRESS",
          words: wordCount(text),
          preview: text.slice(0, 250)
        }).catch(() => {});
      }

      if (sawNew && wordCount(text) > 30 && Date.now() - lastChange >= stableSec * 1000) {
        return text.trim();
      }
    }

    throw new Error("Chờ ChatGPT quá lâu. Hãy kiểm tra tab ChatGPT rồi chạy lại bước này.");
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || !message.type) return;

    if (message.type === "KOVA_PING") {
      sendResponse({
        ok: true,
        url: location.href,
        title: document.title,
        hasComposer: !!findComposer(),
        hasSendButton: !!findSendButton(),
        assistantCount: assistantMessages().length
      });
      return true;
    }

    if (message.type === "KOVA_RUN_PROMPT") {
      sendPrompt(message.prompt, message.options || {})
        .then(answer => sendResponse({ ok: true, answer }))
        .catch(err => sendResponse({ ok: false, error: String(err?.message || err) }));
      return true;
    }
  });
})();
