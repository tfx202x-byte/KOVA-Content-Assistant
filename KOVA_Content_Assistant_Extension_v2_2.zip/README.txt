KOVA Content Assistant Extension v2.2
=====================================

Bản v2.2 thêm tính năng nhiều bộ prompt cho nhiều dự án.

Vấn đề được giải quyết
----------------------
Nếu bạn có nhiều dự án/kênh khác nhau, mỗi dự án có bộ prompt khác nhau, không nên dùng chung một bộ B1→B7.

Ví dụ:
- FE Stories
- FO
- HT
- VH
- MT
- ShadowCipher
- Rich Poor Stories

Mỗi bộ prompt có riêng:
- B1 Phân tích
- B2 Skeleton
- B3 Tóm tắt
- B4 Chương 1
- B5 Chương tiếp
- B6 Chương cuối
- B7 Mô tả

Cách dùng
---------
1. Mở extension.
2. Ở mục "Bộ prompt", chọn bộ prompt phù hợp.
3. Nếu cần bộ mới, bấm "Tạo bộ mới".
4. Nếu muốn lấy bộ hiện tại làm nền, bấm "Nhân bản".
5. Bấm "Sửa prompt" để chỉnh prompt trong bộ đang chọn.
6. Chạy automation như bình thường.

Lưu ý quan trọng
----------------
- Prompt sửa trong mỗi bộ được lưu riêng.
- Update extension sau này không reset prompt đã chỉnh.
- Export JSON sẽ backup cả project hiện tại và toàn bộ bộ prompt.
- Import JSON sẽ khôi phục lại bộ prompt.

Khuyến nghị workflow
--------------------
- Mỗi kênh/chủ đề nên có một bộ prompt riêng.
- Khi tạo kênh mới giống FE, dùng "Nhân bản" từ FE Stories rồi chỉnh dần.
- Không nên sửa trực tiếp bộ prompt gốc nếu muốn giữ bản chuẩn.
