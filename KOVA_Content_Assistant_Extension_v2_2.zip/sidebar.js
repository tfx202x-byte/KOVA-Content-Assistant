const EXT_VERSION = "2.2.0";
const STORAGE_KEY = "kovaContentAssistantV2";
const OLD_KEYS = ["kovaProjectV14", "kovaProjectV11", "kovaProject"];

const OUTPUT_TABS = [
  ["analysis", "B1 Phân tích"],
  ["skeleton", "B2 Skeleton"],
  ["summary", "B3 Tóm tắt"],
  ["chapter1", "B4 Chương 1"],
  ["middleChapters", "B5 Chương giữa"],
  ["finalChapter", "B6 Chương cuối"],
  ["description", "B7 Mô tả"]
];

const PROMPT_TABS = [
  ["analysis", "B1 Phân tích"],
  ["skeleton", "B2 Skeleton"],
  ["summary", "B3 Tóm tắt"],
  ["chapter1", "B4 Chương 1"],
  ["nextChapter", "B5 Chương tiếp"],
  ["finalChapter", "B6 Chương cuối"],
  ["description", "B7 Mô tả"]
];

const DEFAULT_PROMPTS = {
  analysis: `Tôi sẽ cung cấp cho bạn:
TIÊU ĐỀ MỚI: {{NEW_TITLE}}

KỊCH BẢN GỐC:
{{ORIGINAL_SCRIPT}}

Nhiệm vụ của bạn là phân tích kịch bản gốc này dưới góc nhìn storytelling YouTube, giữ chân người xem, cảm xúc, tính viral và SEO.
Mục tiêu phân tích là để rút ra cấu trúc, điểm mạnh, điểm yếu, keyword và các điểm cần cải thiện trước khi xây dựng một câu chuyện mới theo tiêu đề mới.

Yêu cầu:
1. Phân tích cấu trúc kịch bản theo các phần nếu có:
Hook → Intro/Setup → Build/Rising Conflict → Climax → Twist/Reveal → Reflection/Emotional Payoff → CTA/Closing.
Với mỗi phần, nêu rõ:
- Vai trò trong câu chuyện
- Đang làm tốt gì
- Chưa tối ưu ở đâu

2. Chỉ ra điểm mạnh nổi bật:
Storytelling, nhịp kể, khả năng giữ chân, tò mò, xung đột, cao trào, twist, payoff cảm xúc.

3. Chỉ ra ĐIỂM YẾU VÀ CÁCH CẢI THIỆN:
Ngắn gọn, cụ thể, thực tế, bám sát nội dung.
Hãy đặt đúng tiêu đề mục là: "3. Điểm yếu và cách cải thiện"

4. Trích xuất SEO keywords thành 3 nhóm:
- Keyword chính
- Keyword phụ
- Keyword liên quan
Hãy đặt đúng tiêu đề mục là: "4. SEO keywords"

5. Kết luận ngắn:
- Điểm tổng thể /10
- 3 điểm mạnh nhất
- 3 điểm cần cải thiện nhất
- Nhận định tiềm năng thu hút người xem

Yêu cầu trình bày rõ ràng, có mục, không lan man, ưu tiên tính ứng dụng cao.`,

  skeleton: `Tôi sẽ cung cấp cho bạn:
TIÊU ĐỀ MỚI: {{NEW_TITLE}}
ĐỀ XUẤT MỚI: {{DE_XUAT_MOI}}
SEO KEYWORDS: {{SEO_KEYWORDS}}

GHI CHÚ CHỈNH SỬA THÊM TỪ TÔI:
{{EXTRA_NOTES}}

Nhiệm vụ của bạn là viết skeleton dàn ý nhiều chương cho một kịch bản YouTube storytelling hoàn toàn mới.

Mục tiêu:
Tạo một câu chuyện mới hoàn toàn, có thể phát triển thành kịch bản dài khoảng 6,000–9,000 từ, bám sát đúng DNA cảm xúc của kênh Family Echoes.

Skeleton này chỉ dùng để duyệt trước.
Không được:
- viết full chapter
- viết scene-by-scene
- viết prose
- viết hội thoại mẫu
- tự động triển khai thành full script

Yêu cầu bắt buộc:
- Câu chuyện phải believable trong đời sống Mỹ.
- Không drama phi thực tế, không twist thiếu nền tảng, không trùng hợp vô lý.
- Timeline chính tuyến tính.
- POV nhất quán: Third-person, past tense.
- Số chương: bạn phải tự quyết định số chương hiệu quả nhất dựa trên nhịp kể, độ phức tạp, số reveal, độ sâu cảm xúc và khả năng giữ retention. Tối thiểu trên 5 chương.
- Tổng độ dài dự kiến full script: 6,000–9,000 từ.
- Mỗi chương có tiềm năng phát triển thành khoảng 600–800 từ.
- Chương 1 phải có Opening Hook 80–120 từ và dòng END OF HOOK.
- Chương cuối phải có emotional payoff rõ: tình thân, sự thật, phẩm giá, công lý, đoàn tụ hoặc chữa lành.
- Câu chuyện mới phải thay đổi toàn bộ: tên nhân vật, độ tuổi, nghề nghiệp, địa điểm, tầng lớp xã hội, quan hệ gia đình, xung đột chính, twist, climax, payoff, ending.
- Không được tạo cảm giác đây chỉ là câu chuyện cũ đổi tên nhân vật.

Với mỗi chương, trình bày đúng format:
Chapter Title
Purpose:
Main Beats:
Core Conflict:
Secret / Reveal / Emotional Turn:
Escalation Value:
Human Value Layer:
SEO Keyword Placement:
End Hook / Cliffhanger:

Output bắt đầu bằng:
Suggested Chapter Count:
Estimated Total Length:

Sau đó trình bày từ Chapter 1 đến chương cuối.`,

  summary: `Hãy tóm tắt ngắn gọn câu chuyện mới bạn vừa viết khung dàn ý bên trên, để tôi hiểu câu chuyện và kiểm tra tính logic.

Dàn ý đã duyệt:
{{SKELETON}}`,

  chapter1: `Dựa vào dàn ý Chương 1 đã được duyệt trước đó.
Nhiệm vụ của bạn là viết Chương 1 bằng tiếng Anh, bám sát tuyệt đối dàn ý đã duyệt.
Độ dài mục tiêu: 600–800 từ.

Yêu cầu:
- Chỉ viết nội dung chương.
- Không phân tích.
- Không giải thích.
- Không mở bài chung chung.
- Không dùng các nhãn như “Chapter 1”, “Hook” hoặc bất kỳ ghi chú kỹ thuật nào khác.
- Third-person, past tense.
- American English tự nhiên, rõ, giàu cảm xúc, dễ nghe bằng voice AI.
- Mở đầu bằng opening hook 50–80 từ.
- Sau hook chèn nguyên văn:
“Welcome to today’s story. If you enjoy emotional drama and shocking twists, don’t forget to like this video and subscribe for more unforgettable stories. And before we begin, let me know where you’re watching from in the comments.”
- Sau đó ghi đúng:
END OF HOOK
- Sau đó viết một câu chuyển ngắn, tự nhiên để quay về điểm bắt đầu.
- Kết thúc chương bằng cliffhanger mạnh.

Dàn ý đã duyệt:
{{SKELETON}}`,

  nextChapter: `Hãy viết chương tiếp theo của câu chuyện bằng tiếng Anh, bám đúng dàn ý đã duyệt và nối mạch tự nhiên với các chương trước đó.
Độ dài mục tiêu: 600–800 từ.
Lưu ý đây chưa phải chương cuối, đây là chương {{CHAPTER_NUMBER}} của {{CHAPTER_COUNT}} chương.

Yêu cầu:
- Chỉ viết nội dung chương bằng tiếng Anh.
- Ghi số thứ tự chương ở đầu.
- Không ghi tiêu đề chương, không heading, không subheading, không bullet point, không meta commentary.
- Third-person, past tense.
- Văn phong tự nhiên, rõ, giàu cảm xúc, dễ nghe bằng voice AI.
- Cuối chương có hook hoặc cliffhanger mạnh.

Dàn ý đã duyệt:
{{SKELETON}}

Tóm tắt câu chuyện:
{{SUMMARY}}

Các chương đã viết:
{{CHAPTERS}}`,

  finalChapter: `Hãy viết chương cuối của câu chuyện bằng tiếng Anh, bám đúng dàn ý đã duyệt và nối mạch chặt chẽ với các chương trước đó.
Độ dài mục tiêu: 400–600 từ.

Yêu cầu:
- Chỉ viết nội dung chương.
- Ghi số thứ tự chương ở đầu.
- Không heading, subheading, bullet point hoặc meta commentary.
- Hoàn tất xung đột chính.
- Trả payoff cho bí mật, cảm xúc, lựa chọn đạo đức và quan hệ gia đình.
- Kết thúc có emotional justice, healing, hoặc phẩm giá được phục hồi.
- CTA cuối chương thật tự nhiên, ngắn, mềm.

Dàn ý đã duyệt:
{{SKELETON}}

Tóm tắt câu chuyện:
{{SUMMARY}}

Các chương đã viết:
{{CHAPTERS}}`,

  description: `Tiêu đề mới:
{{NEW_TITLE}}

Tóm tắt video:
{{SUMMARY}}

Nhiệm vụ của bạn là viết:
1 dòng SEO thô
1 đoạn mô tả bằng tiếng Anh dài 60–70 từ
1 bản dịch tiếng Việt
5 tags tối ưu nhất cho video

Yêu cầu:
- Chuẩn SEO YouTube.
- Bám sát đúng tóm tắt video, không bịa thêm.
- Văn phong tự nhiên, giàu kịch tính, đúng Family Echoes.
- Output 4 dòng:
Dòng 1: SEO thô
Dòng 2: English description
Dòng 3: Bản dịch tiếng Việt
Dòng 4: 5 tags, ngăn cách bằng dấu phẩy`
};

let state = freshState();
let isRunning = false;
let stopRequested = false;

function freshState(keepProfiles, activeProfile) {
  const profiles = keepProfiles || {
    "FE Stories": { ...DEFAULT_PROMPTS }
  };

  const profileName = activeProfile && profiles[activeProfile]
    ? activeProfile
    : Object.keys(profiles)[0] || "FE Stories";

  return {
    appVersion: EXT_VERSION,
    projectCode: "FE-" + new Date().toISOString().slice(11,19).replaceAll(":",""),
    newTitle: "",
    originalScript: "",
    extraNotes: "",
    totalChapterCount: "",
    nextChapterNumber: 2,
    activeOutput: "analysis",
    currentPromptProfile: profileName,
    outputs: {
      analysis: "",
      skeleton: "",
      summary: "",
      description: ""
    },
    extracted: {
      deXuatMoi: "",
      seoKeywords: ""
    },
    chapters: {},
    promptProfiles: profiles
  };
}

function getPromptProfiles() {
  if (!state.promptProfiles || typeof state.promptProfiles !== "object") {
    const legacy = state.promptTemplates || state.prompts || DEFAULT_PROMPTS;
    state.promptProfiles = { "FE Stories": Object.assign({}, DEFAULT_PROMPTS, legacy) };
    state.currentPromptProfile = "FE Stories";
  }
  return state.promptProfiles;
}

function currentPrompts() {
  const profiles = getPromptProfiles();
  const name = state.currentPromptProfile && profiles[state.currentPromptProfile]
    ? state.currentPromptProfile
    : Object.keys(profiles)[0];

  state.currentPromptProfile = name;
  profiles[name] = Object.assign({}, DEFAULT_PROMPTS, profiles[name] || {});
  return profiles[name];
}


const $ = id => document.getElementById(id);

function log(msg) {
  const el = $("log");
  const t = new Date().toLocaleTimeString("vi-VN");
  el.textContent += `[${t}] ${msg}\n`;
  el.scrollTop = el.scrollHeight;
}

function wc(text) {
  const m = (text || "").trim().match(/\S+/g);
  return m ? m.length : 0;
}

function setRunning(value) {
  isRunning = value;
  document.querySelectorAll("[data-run], #btnAutoB1B2, #btnAutoB1B3, #btnAutoFullScript, #btnNextChapter, #btnAutoMiddle").forEach(btn => {
    if (btn) btn.disabled = value;
  });
}

function syncInputs() {
  state.projectCode = $("projectCode").value.trim();
  state.newTitle = $("newTitle").value.trim();
  state.originalScript = $("originalScript").value.trim();
  state.extraNotes = $("extraNotes").value.trim();
  state.nextChapterNumber = Number($("nextChapterNumber").value || 2);
  state.totalChapterCount = $("totalChapterCount").value.trim();
  state.appVersion = EXT_VERSION;
}

function currentOutputValue() {
  const key = $("outputBox").dataset.outputKey || state.activeOutput;
  return { key, value: $("outputBox").value };
}

function saveVisibleOutput() {
  const { key, value } = currentOutputValue();
  if (["analysis", "skeleton", "summary", "description"].includes(key)) {
    state.outputs[key] = value;
  } else if (key.startsWith("chapter:")) {
    const n = key.split(":")[1];
    state.chapters[n] = value;
  } else if (key === "middleChapters") {
    // view-only aggregate; do not overwrite chapter map
  }
}

async function saveRaw() {
  state.appVersion = EXT_VERSION;
  await chrome.storage.local.set({ [STORAGE_KEY]: state });
}

async function saveAllFromUI() {
  syncInputs();
  saveVisibleOutput();
  await saveRaw();
}

async function loadState() {
  const keys = [STORAGE_KEY, ...OLD_KEYS];
  const data = await chrome.storage.local.get(keys);
  const loaded = data[STORAGE_KEY] || data.kovaProjectV14 || data.kovaProjectV11 || data.kovaProject;

  if (loaded) {
    let profiles = loaded.promptProfiles || null;

    // migrate v2.1/v1.x single prompt set into one profile
    if (!profiles) {
      const legacyPrompts = loaded.promptTemplates || loaded.prompts || DEFAULT_PROMPTS;
      profiles = {
        "FE Stories": Object.assign({}, DEFAULT_PROMPTS, legacyPrompts)
      };
    } else {
      for (const name of Object.keys(profiles)) {
        profiles[name] = Object.assign({}, DEFAULT_PROMPTS, profiles[name] || {});
      }
    }

    const activeProfile = loaded.currentPromptProfile || Object.keys(profiles)[0] || "FE Stories";
    state = Object.assign(freshState(profiles, activeProfile), loaded);
    state.promptProfiles = profiles;
    state.currentPromptProfile = activeProfile;

    state.outputs = Object.assign(freshState().outputs, loaded.outputs || {});
    state.extracted = Object.assign({ deXuatMoi: "", seoKeywords: "" }, loaded.extracted || {});
    state.chapters = Object.assign({}, loaded.chapters || {});

    // migrate old output fields if existed
    if (loaded.outputs?.chapter1 && !state.chapters["1"]) state.chapters["1"] = loaded.outputs.chapter1;
    if (loaded.outputs?.finalChapter) {
      const t = Number(loaded.totalChapterCount || "") || parseChapterCount(loaded.outputs?.skeleton || "");
      if (t && !state.chapters[String(t)]) state.chapters[String(t)] = loaded.outputs.finalChapter;
    }

    state.appVersion = EXT_VERSION;
  } else {
    state = freshState();
  }

  await saveRaw();
  renderAll();
  log(`Extension v${EXT_VERSION} sẵn sàng. Hỗ trợ nhiều bộ prompt cho nhiều dự án.`);
}

function renderAll() {
  $("projectCode").value = state.projectCode || "";
  $("newTitle").value = state.newTitle || "";
  $("originalScript").value = state.originalScript || "";
  $("extraNotes").value = state.extraNotes || "";
  $("nextChapterNumber").value = state.nextChapterNumber || 2;
  $("totalChapterCount").value = state.totalChapterCount || "";
  renderPromptProfileSelect();
  renderTabs();
  renderOutput();
  renderPromptSelect();
}

function renderTabs() {
  const tabs = $("tabs");
  tabs.innerHTML = "";

  OUTPUT_TABS.forEach(([key, name]) => addTab(tabs, key, name));

  const chapterNums = Object.keys(state.chapters || {}).map(Number).sort((a,b)=>a-b);
  chapterNums.forEach(n => addTab(tabs, `chapter:${n}`, `Ch.${n}`));
}

function addTab(container, key, name) {
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "tab" + (state.activeOutput === key ? " active" : "");
  btn.textContent = name;
  btn.onclick = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    syncInputs();
    saveVisibleOutput();
    state.activeOutput = key;
    await saveRaw();
    renderTabs();
    renderOutput();
  };
  container.appendChild(btn);
}

function getOutputText(key) {
  if (key === "analysis") return state.outputs.analysis || "";
  if (key === "skeleton") return state.outputs.skeleton || "";
  if (key === "summary") return state.outputs.summary || "";
  if (key === "description") return state.outputs.description || "";
  if (key === "chapter1") return state.chapters["1"] || "";
  if (key === "finalChapter") {
    const total = getTotalChapterCount();
    return total ? (state.chapters[String(total)] || "") : "";
  }
  if (key === "middleChapters") return buildMiddleChaptersText();
  if (key.startsWith("chapter:")) return state.chapters[key.split(":")[1]] || "";
  return "";
}

function getOutputTitle(key) {
  if (key === "analysis") return "B1 Phân tích";
  if (key === "skeleton") return "B2 Skeleton";
  if (key === "summary") return "B3 Tóm tắt";
  if (key === "chapter1") return "B4 Chương 1";
  if (key === "middleChapters") return "B5 Các chương giữa";
  if (key === "finalChapter") return "B6 Chương cuối";
  if (key === "description") return "B7 Mô tả";
  if (key.startsWith("chapter:")) return `Chương ${key.split(":")[1]}`;
  return key;
}

function renderOutput() {
  const key = state.activeOutput;
  const text = getOutputText(key);
  $("activeTitle").textContent = getOutputTitle(key);
  $("outputBox").dataset.outputKey = key;
  $("outputBox").value = text;
  $("wordCount").textContent = `${wc(text)} từ`;
}

function renderPromptProfileSelect() {
  const sel = $("promptProfileSelect");
  if (!sel) return;

  const profiles = getPromptProfiles();
  sel.innerHTML = "";

  Object.keys(profiles).sort().forEach(name => {
    const opt = document.createElement("option");
    opt.value = name;
    opt.textContent = name;
    sel.appendChild(opt);
  });

  sel.value = state.currentPromptProfile || Object.keys(profiles)[0] || "FE Stories";
}

function renderPromptSelect() {
  const sel = $("promptSelect");
  const current = sel.value || "analysis";
  sel.innerHTML = "";
  PROMPT_TABS.forEach(([key, name]) => {
    const opt = document.createElement("option");
    opt.value = key;
    opt.textContent = name;
    sel.appendChild(opt);
  });
  const prompts = currentPrompts();
  sel.value = prompts[current] ? current : "analysis";
  $("promptBox").value = prompts[sel.value] || "";
}

function normalize(text) {
  return (text || "").replace(/\r/g, "\n").replace(/\u00A0/g, " ").replace(/[ \t]+/g, " ");
}

function lineIndex(lines, patterns, from = 0) {
  for (let i = from; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    if (patterns.some(p => p.test(line))) return i;
  }
  return -1;
}

function blockByHeading(text, startPatterns, endPatterns) {
  const lines = normalize(text).split("\n");
  const s = lineIndex(lines, startPatterns);
  if (s === -1) return "";
  let e = lines.length;
  for (let i = s + 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    if (endPatterns.some(p => p.test(line))) {
      e = i;
      break;
    }
  }
  return lines.slice(s + 1, e).join("\n").trim();
}

function extractFromAnalysis() {
  const text = state.outputs.analysis || "";
  const deXuat = blockByHeading(
    text,
    [
      /^(?:#{1,6}\s*)?(?:\*\*)?\s*(?:iii|3|ba)?\s*[\.\)]?\s*điểm\s*yếu\s*(?:và|&)\s*cách\s*cải\s*thiện\s*(?:\*\*)?\s*:?$/i,
      /^(?:#{1,6}\s*)?(?:\*\*)?\s*weaknesses?\s*(?:and|&)\s*improvements?\s*(?:\*\*)?\s*:?$/i
    ],
    [
      /^(?:#{1,6}\s*)?(?:\*\*)?\s*(?:iv|4|bốn)?\s*[\.\)]?\s*seo\s*keywords?\s*(?:\*\*)?\s*:?$/i,
      /^(?:#{1,6}\s*)?(?:\*\*)?\s*(?:iv|4)?\s*[\.\)]?\s*từ\s*kh[oó]a\s*(?:\*\*)?\s*:?$/i,
      /^(?:#{1,6}\s*)?(?:\*\*)?\s*(?:v|5)?\s*[\.\)]?\s*kết\s*luận\s*(?:\*\*)?\s*:?$/i
    ]
  );
  const seo = blockByHeading(
    text,
    [
      /^(?:#{1,6}\s*)?(?:\*\*)?\s*(?:iv|4|bốn)?\s*[\.\)]?\s*seo\s*keywords?\s*(?:\*\*)?\s*:?$/i,
      /^(?:#{1,6}\s*)?(?:\*\*)?\s*(?:iv|4)?\s*[\.\)]?\s*từ\s*kh[oó]a\s*(?:\*\*)?\s*:?$/i
    ],
    [
      /^(?:#{1,6}\s*)?(?:\*\*)?\s*(?:v|5|năm)?\s*[\.\)]?\s*kết\s*luận\s*(?:\*\*)?\s*:?$/i,
      /^(?:#{1,6}\s*)?(?:\*\*)?\s*conclusion\s*(?:\*\*)?\s*:?$/i
    ]
  );
  state.extracted.deXuatMoi = deXuat || "[Không tách được mục Điểm yếu và cách cải thiện từ B1. Hãy kiểm tra output B1.]";
  state.extracted.seoKeywords = seo || "[Không tách được mục SEO keywords từ B1. Hãy kiểm tra output B1.]";
  return state.extracted;
}

function parseChapterCount(skeleton) {
  const text = skeleton || "";
  const patterns = [
    /Suggested\s+Chapter\s+Count\s*[:：\-]?\s*(\d{1,2})/i,
    /Suggested\s+Chapters?\s*[:：\-]?\s*(\d{1,2})/i,
    /Chapter\s+Count\s*[:：\-]?\s*(\d{1,2})/i,
    /Số\s+chương\s+(?:đề\s+xuất|gợi\s+ý|suggested)?\s*[:：\-]?\s*(\d{1,2})/i,
    /Tổng\s+số\s+chương\s*[:：\-]?\s*(\d{1,2})/i
  ];
  for (const p of patterns) {
    const m = text.match(p);
    if (m && Number(m[1]) >= 2) return Number(m[1]);
  }
  const nums = [...text.matchAll(/(?:^|\n)\s*(?:#{1,6}\s*)?(?:Chapter|Chương)\s+(\d{1,2})\b/gi)].map(x => Number(x[1]));
  return nums.length ? Math.max(...nums) : null;
}

function getTotalChapterCount() {
  const manual = Number(state.totalChapterCount || $("totalChapterCount").value || 0);
  if (manual && manual >= 2) return manual;
  const parsed = parseChapterCount(state.outputs.skeleton || "");
  if (parsed && parsed >= 2) {
    state.totalChapterCount = String(parsed);
    $("totalChapterCount").value = String(parsed);
    return parsed;
  }
  return null;
}

function buildMiddleChaptersText() {
  const total = getTotalChapterCount();
  const nums = Object.keys(state.chapters || {})
    .map(Number)
    .filter(n => n >= 2 && (!total || n < total))
    .sort((a,b)=>a-b);
  return nums.map(n => state.chapters[String(n)]).filter(Boolean).join("\n\n");
}

function buildFullScriptOrdered() {
  const nums = Object.keys(state.chapters || {}).map(Number).sort((a,b)=>a-b);
  if (nums.length) return nums.map(n => state.chapters[String(n)]).filter(Boolean).join("\n\n");
  return "";
}

function replaceLegacy(out, vars) {
  const map = {
    "[TIÊU ĐỀ MỚI]": vars.NEW_TITLE,
    "[TIÊU_ĐỀ_MỚI]": vars.NEW_TITLE,
    "[TIEU_DE_MOI]": vars.NEW_TITLE,
    "[Tieu_de_moi]": vars.NEW_TITLE,
    "[KỊCH BẢN GỐC]": vars.ORIGINAL_SCRIPT,
    "[KỊCH_BẢN_GỐC]": vars.ORIGINAL_SCRIPT,
    "[KICH_BAN_GOC]": vars.ORIGINAL_SCRIPT,
    "[KẾT_QUẢ_PHÂN_TÍCH]": vars.ANALYSIS,
    "[ĐIỂM YẾU VÀ CÁCH CẢI THIỆN TỪ BƯỚC 1]": vars.DE_XUAT_MOI,
    "[ĐỀ XUẤT MỚI]": vars.DE_XUAT_MOI,
    "[DE_XUAT_MOI]": vars.DE_XUAT_MOI,
    "[SEO KEYWORDS TỪ BƯỚC 1]": vars.SEO_KEYWORDS,
    "[SEO KEYWORDS]": vars.SEO_KEYWORDS,
    "[SEO_Keyword]": vars.SEO_KEYWORDS,
    "[DÀN_Ý_ĐÃ_DUYỆT]": vars.SKELETON,
    "[DÀN Ý ĐÃ DUYỆT]": vars.SKELETON,
    "[TÓM_TẮT_VIDEO]": vars.SUMMARY,
    "[TÓM TẮT VIDEO]": vars.SUMMARY,
    "[CÁC CHƯƠNG ĐÃ VIẾT]": vars.CHAPTERS,
    "[SỐ_CHƯƠNG_THEO_SKELETON]": vars.CHAPTER_COUNT,
    "[Không có ghi chú thêm]": vars.EXTRA_NOTES
  };
  for (const [k,v] of Object.entries(map)) out = out.split(k).join(v ?? "");
  return out;
}

function renderTemplate(step, chapterNumber) {
  const prompts = currentPrompts();
  const template = prompts[step];
  if (!template) throw new Error("Không tìm thấy prompt trong bộ " + state.currentPromptProfile + ": " + step);

  const extracted = extractFromAnalysis();
  const total = getTotalChapterCount();
  const vars = {
    NEW_TITLE: state.newTitle || "[TIÊU_ĐỀ_MỚI]",
    ORIGINAL_SCRIPT: state.originalScript || "[KỊCH_BẢN_GỐC]",
    ANALYSIS: state.outputs.analysis || "[KẾT_QUẢ_PHÂN_TÍCH]",
    DE_XUAT_MOI: extracted.deXuatMoi || "[ĐIỂM YẾU VÀ CÁCH CẢI THIỆN TỪ BƯỚC 1]",
    SEO_KEYWORDS: extracted.seoKeywords || "[SEO KEYWORDS TỪ BƯỚC 1]",
    SKELETON: state.outputs.skeleton || "[DÀN_Ý_ĐÃ_DUYỆT]",
    SUMMARY: state.outputs.summary || "[TÓM_TẮT_VIDEO]",
    CHAPTERS: buildFullScriptOrdered() || "[CÁC CHƯƠNG ĐÃ VIẾT]",
    CHAPTER_NUMBER: chapterNumber || state.nextChapterNumber || 2,
    CHAPTER_COUNT: total || "[SỐ_CHƯƠNG_THEO_SKELETON]",
    EXTRA_NOTES: state.extraNotes || "[Không có ghi chú thêm]"
  };

  let out = template.replace(/\{\{([A-Z_]+)\}\}/g, (_, name) => vars[name] ?? "");
  return replaceLegacy(out, vars);
}

async function getChatGPTTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const active = tabs[0];
  if (active && /https:\/\/(chatgpt\.com|chat\.openai\.com)\//.test(active.url || "")) return active;

  const all = await chrome.tabs.query({ url: ["https://chatgpt.com/*", "https://chat.openai.com/*"] });
  if (all.length) return all[0];

  throw new Error("Không tìm thấy tab ChatGPT. Hãy mở đúng Project/đoạn chat trên chatgpt.com trước.");
}

async function ensureContentScript(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "KOVA_PING" });
  } catch {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
  }
}

async function pingChatGPT() {
  const tab = await getChatGPTTab();
  await ensureContentScript(tab.id);
  return chrome.tabs.sendMessage(tab.id, { type: "KOVA_PING" });
}

async function sendToChatGPT(prompt) {
  const tab = await getChatGPTTab();
  await ensureContentScript(tab.id);
  await chrome.tabs.update(tab.id, { active: true });
  const res = await chrome.tabs.sendMessage(tab.id, {
    type: "KOVA_RUN_PROMPT",
    prompt,
    options: { timeoutSec: 900, stableSec: 14 }
  });
  if (!res || !res.ok) throw new Error(res?.error || "Không nhận được output từ ChatGPT.");
  return res.answer || "";
}

async function runStep(step, opts = {}) {
  if (!opts.internal && isRunning) {
    log("Đang chạy automation khác.");
    return;
  }
  if (!opts.internal) setRunning(true);

  try {
    syncInputs();
    await saveRaw();

    if (!state.newTitle || !state.originalScript) {
      alert("Bạn cần nhập Tiêu đề mới và Kịch bản gốc trước.");
      return;
    }

    const promptStep = step === "nextChapter" ? "nextChapter" : step;
    const answer = await sendToChatGPT(renderTemplate(promptStep, opts.chapterNumber));

    if (step === "analysis") {
      state.outputs.analysis = answer;
      extractFromAnalysis();
      state.activeOutput = "analysis";
    } else if (step === "skeleton") {
      state.outputs.skeleton = answer;
      const t = parseChapterCount(answer);
      if (t) state.totalChapterCount = String(t);
      state.activeOutput = "skeleton";
    } else if (step === "summary") {
      state.outputs.summary = answer;
      state.activeOutput = "summary";
    } else if (step === "chapter1") {
      state.chapters["1"] = answer;
      state.activeOutput = "chapter:1";
    } else if (step === "nextChapter") {
      const n = Number(opts.chapterNumber || state.nextChapterNumber || 2);
      state.chapters[String(n)] = answer;
      state.nextChapterNumber = n + 1;
      state.activeOutput = `chapter:${n}`;
    } else if (step === "finalChapter") {
      const total = getTotalChapterCount();
      if (!total) throw new Error("Chưa có Tổng số chương. Hãy nhập tay hoặc kiểm tra Skeleton.");
      state.chapters[String(total)] = answer;
      state.activeOutput = `chapter:${total}`;
    } else if (step === "description") {
      state.outputs.description = answer;
      state.activeOutput = "description";
    }

    await saveRaw();
    renderAll();
    log(`Đã lưu ${step}: ${wc(answer)} từ.`);
  } finally {
    if (!opts.internal) setRunning(false);
  }
}

async function autoB1B2() {
  if (isRunning) return;
  setRunning(true);
  try {
    await runStep("analysis", { internal: true });
    await runStep("skeleton", { internal: true });
    log("Đã chạy xong B1→B2.");
  } catch (e) {
    log("LỖI: " + e.message);
    alert(e.message);
  } finally {
    setRunning(false);
  }
}

async function autoB1B3() {
  if (isRunning) return;
  setRunning(true);
  try {
    await runStep("analysis", { internal: true });
    await runStep("skeleton", { internal: true });
    await runStep("summary", { internal: true });
    log("Đã chạy xong B1→B3. Dừng lại để bạn duyệt.");
  } catch (e) {
    log("LỖI: " + e.message);
    alert(e.message);
  } finally {
    setRunning(false);
  }
}

async function autoMiddleChapters() {
  if (isRunning) return;
  setRunning(true);
  try {
    syncInputs();
    await saveRaw();

    const total = getTotalChapterCount();
    if (!total || total < 6) {
      alert("Không đọc được tổng số chương. Hãy nhập tay vào ô Tổng số chương.");
      return;
    }

    let current = Number(state.nextChapterNumber || 2);
    const lastMiddle = total - 1;

    if (current > lastMiddle) {
      alert(`Không còn chương giữa. Tổng ${total} chương, chương cuối là ${total}.`);
      return;
    }

    stopRequested = false;
    log(`Auto chương giữa: Chương ${current} → Chương ${lastMiddle}. Mỗi chương gửi prompt riêng.`);

    while (current <= lastMiddle) {
      if (stopRequested) {
        log("Đã dừng auto chương giữa.");
        break;
      }
      await runStep("nextChapter", { chapterNumber: current, internal: true });
      current = Number(state.nextChapterNumber || current + 1);
      await new Promise(r => setTimeout(r, 1800));
    }

    if (!stopRequested) log("Đã viết xong các chương giữa. Hãy chạy B6 chương cuối.");
  } catch (e) {
    log("LỖI auto chương giữa: " + e.message);
    alert(e.message);
  } finally {
    setRunning(false);
  }
}

async function autoFullScript() {
  if (isRunning) return;
  setRunning(true);

  try {
    syncInputs();
    await saveRaw();

    const total = getTotalChapterCount();
    if (!total || total < 6) {
      alert("Không đọc được tổng số chương. Hãy nhập tay vào ô Tổng số chương trước khi bấm Auto viết full script.");
      return;
    }

    const hasExistingChapters = Object.keys(state.chapters || {}).length > 0;
    if (hasExistingChapters) {
      const ok = confirm("Đã có một số chương được lưu. Auto viết full script sẽ viết lại từ Chương 1 đến Chương cuối và có thể ghi đè các chương cũ. Tiếp tục?");
      if (!ok) return;
    }

    // Clear old chapters to avoid mixed old/new content.
    state.chapters = {};
    state.nextChapterNumber = 2;
    await saveRaw();
    renderAll();

    stopRequested = false;
    log(`Bắt đầu Auto viết full script: Chương 1 → Chương ${total}. Mỗi chương gửi một prompt riêng.`);

    if (stopRequested) return;
    await runStep("chapter1", { internal: true });

    for (let chapter = 2; chapter <= total - 1; chapter++) {
      if (stopRequested) {
        log("Đã dừng auto full script sau khi hoàn tất chương hiện tại.");
        break;
      }

      state.nextChapterNumber = chapter;
      $("nextChapterNumber").value = chapter;
      await saveRaw();

      await runStep("nextChapter", { chapterNumber: chapter, internal: true });
      await new Promise(r => setTimeout(r, 1800));
    }

    if (!stopRequested) {
      await runStep("finalChapter", { internal: true });
      log("Đã viết xong full script từ Chương 1 đến chương cuối. Bạn có thể bấm Export TXT.");
    }
  } catch (e) {
    log("LỖI Auto viết full script: " + e.message);
    alert(e.message);
  } finally {
    setRunning(false);
  }
}


async function checkTab() {
  try {
    const res = await pingChatGPT();
    $("statusDot").classList.toggle("ok", !!res.ok);
    $("status").textContent = res.ok
      ? `Đã kết nối: ${res.title || res.url}. Composer: ${res.hasComposer ? "OK" : "chưa thấy"} · Send: ${res.hasSendButton ? "OK" : "fallback Enter"}`
      : "Chưa kết nối.";
    log("Kiểm tra ChatGPT: " + JSON.stringify(res));
  } catch (e) {
    $("statusDot").classList.remove("ok");
    $("status").textContent = e.message;
    log("LỖI kiểm tra: " + e.message);
  }
}

async function exportJSON() {
  await saveAllFromUI();
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
  downloadBlob(blob, `${state.projectCode || "kova-project"}.json`);
}

async function exportTXT() {
  await saveAllFromUI();
  const script = buildFullScriptOrdered().trim();

  if (!script) {
    alert("Chưa có nội dung chương để export. Hãy chạy B4/B5/B6 hoặc Auto viết full script trước.");
    return;
  }

  // Content-only export: only Chapter 1 → final chapter, no title, no summary, no description.
  downloadBlob(new Blob([script], { type: "text/plain;charset=utf-8" }), `${state.projectCode || "kova-full-content"}.txt`);
}

function downloadBlob(blob, name) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}

function importJSONFile(file) {
  const reader = new FileReader();
  reader.onload = async () => {
    try {
      const imported = JSON.parse(reader.result);

      let profiles = imported.promptProfiles || state.promptProfiles || null;
      if (!profiles) {
        const legacy = imported.promptTemplates || imported.prompts || state.promptTemplates || DEFAULT_PROMPTS;
        profiles = { "FE Stories": Object.assign({}, DEFAULT_PROMPTS, legacy) };
      }
      for (const name of Object.keys(profiles)) {
        profiles[name] = Object.assign({}, DEFAULT_PROMPTS, profiles[name] || {});
      }

      const activeProfile = imported.currentPromptProfile || state.currentPromptProfile || Object.keys(profiles)[0];
      state = Object.assign(freshState(profiles, activeProfile), imported);
      state.promptProfiles = profiles;
      state.currentPromptProfile = activeProfile;
      state.outputs = Object.assign(freshState().outputs, imported.outputs || {});
      state.chapters = Object.assign({}, imported.chapters || {});
      state.appVersion = EXT_VERSION;
      await saveRaw();
      renderAll();
      log("Import thành công.");
    } catch {
      alert("File JSON không hợp lệ.");
    }
  };
  reader.readAsText(file);
}

function newProject() {
  if (!confirm("Tạo project mới? Prompt tùy chỉnh sẽ được giữ nguyên.")) return;
  const keepProfiles = state.promptProfiles || { "FE Stories": { ...DEFAULT_PROMPTS } };
  const activeProfile = state.currentPromptProfile;
  state = freshState(keepProfiles, activeProfile);
  saveRaw().then(renderAll);
}

chrome.runtime.onMessage.addListener(message => {
  if (message?.type === "KOVA_PROGRESS") {
    if (message.status) log(message.status);
    if (message.words) log(`ChatGPT đang trả lời... ${message.words} từ`);
  }
});

document.addEventListener("input", async e => {
  if (["projectCode", "newTitle", "originalScript", "extraNotes", "nextChapterNumber", "totalChapterCount"].includes(e.target.id)) {
    syncInputs();
    await saveRaw();
  }
  if (e.target.id === "outputBox") {
    $("wordCount").textContent = `${wc($("outputBox").value)} từ`;
    saveVisibleOutput();
    await saveRaw();
  }
});

document.addEventListener("DOMContentLoaded", async () => {
  await loadState();

  $("outputBox").addEventListener("click", e => e.stopPropagation());

  $("btnCheck").onclick = checkTab;
  $("btnNew").onclick = newProject;
  $("btnSaveInputs").onclick = async () => { await saveAllFromUI(); log("Đã lưu input/output hiện tại."); };
  $("btnExportJson").onclick = exportJSON;
  $("btnImportJson").onclick = () => $("importFile").click();
  $("importFile").onchange = e => e.target.files[0] && importJSONFile(e.target.files[0]);

  $("promptProfileSelect").onchange = async () => {
    syncInputs();
    saveVisibleOutput();
    state.currentPromptProfile = $("promptProfileSelect").value;
    await saveRaw();
    renderPromptSelect();
    log("Đã chuyển sang bộ prompt: " + state.currentPromptProfile);
  };

  $("btnNewProfile").onclick = async () => {
    const name = prompt("Tên bộ prompt mới:");
    if (!name) return;
    const profiles = getPromptProfiles();
    if (profiles[name]) {
      alert("Bộ prompt này đã tồn tại.");
      return;
    }
    profiles[name] = { ...DEFAULT_PROMPTS };
    state.currentPromptProfile = name;
    await saveRaw();
    renderAll();
    log("Đã tạo bộ prompt mới: " + name);
  };

  $("btnDuplicateProfile").onclick = async () => {
    const from = state.currentPromptProfile;
    const name = prompt("Tên bộ prompt nhân bản:", from + " Copy");
    if (!name) return;
    const profiles = getPromptProfiles();
    if (profiles[name]) {
      alert("Bộ prompt này đã tồn tại.");
      return;
    }
    profiles[name] = JSON.parse(JSON.stringify(currentPrompts()));
    state.currentPromptProfile = name;
    await saveRaw();
    renderAll();
    log("Đã nhân bản bộ prompt: " + from + " → " + name);
  };

  $("btnDeleteProfile").onclick = async () => {
    const profiles = getPromptProfiles();
    const names = Object.keys(profiles);
    if (names.length <= 1) {
      alert("Cần giữ ít nhất 1 bộ prompt.");
      return;
    }
    const name = state.currentPromptProfile;
    if (!confirm("Xóa bộ prompt: " + name + "?")) return;
    delete profiles[name];
    state.currentPromptProfile = Object.keys(profiles)[0];
    await saveRaw();
    renderAll();
    log("Đã xóa bộ prompt: " + name);
  };

  $("btnAutoB1B2").onclick = autoB1B2;
  $("btnAutoB1B3").onclick = autoB1B3;
  $("btnAutoFullScript").onclick = autoFullScript;
  document.querySelectorAll("[data-run]").forEach(btn => {
    btn.onclick = async () => {
      const step = btn.dataset.run;
      try { await runStep(step); }
      catch(e) { log("LỖI: " + e.message); alert(e.message); setRunning(false); }
    };
  });

  $("btnNextChapter").onclick = async () => {
    try { await runStep("nextChapter", { chapterNumber: Number($("nextChapterNumber").value || 2) }); }
    catch(e) { log("LỖI: " + e.message); alert(e.message); setRunning(false); }
  };

  $("btnAutoMiddle").onclick = autoMiddleChapters;
  $("btnStopAuto").onclick = () => { stopRequested = true; log("Đã yêu cầu dừng auto sau khi chương hiện tại hoàn tất."); };

  $("btnSaveOutput").onclick = async () => { await saveAllFromUI(); log("Đã lưu output."); };
  $("btnCopyOutput").onclick = async () => { await navigator.clipboard.writeText($("outputBox").value); log("Đã copy output."); };
  $("btnExportTxt").onclick = exportTXT;

  $("btnPromptEditor").onclick = () => $("promptEditor").classList.toggle("hidden");
  $("btnClosePromptEditor").onclick = () => $("promptEditor").classList.add("hidden");
  $("promptSelect").onchange = () => $("promptBox").value = currentPrompts()[$("promptSelect").value] || "";
  $("btnSavePrompt").onclick = async () => {
    const prompts = currentPrompts();
    prompts[$("promptSelect").value] = $("promptBox").value;
    await saveRaw();
    log("Đã lưu prompt tùy chỉnh cho bộ: " + state.currentPromptProfile);
  };
  $("btnResetPrompt").onclick = async () => {
    const k = $("promptSelect").value;
    if (!confirm("Reset prompt này về mặc định trong bộ hiện tại?")) return;
    currentPrompts()[k] = DEFAULT_PROMPTS[k];
    $("promptBox").value = currentPrompts()[k];
    await saveRaw();
    log("Đã reset prompt: " + k + " trong bộ " + state.currentPromptProfile);
  };
  $("btnResetAllPrompts").onclick = async () => {
    if (!confirm("Reset toàn bộ prompt của bộ hiện tại về mặc định?")) return;
    state.promptProfiles[state.currentPromptProfile] = { ...DEFAULT_PROMPTS };
    renderPromptSelect();
    await saveRaw();
    log("Đã reset toàn bộ prompt của bộ: " + state.currentPromptProfile);
  };
});
