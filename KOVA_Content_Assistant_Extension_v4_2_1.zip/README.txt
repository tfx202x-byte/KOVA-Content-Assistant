KOVA Content Assistant Extension v4.1.9
=======================================

Bản v4.1.1 là bản tối ưu sau v4.1.

Điểm mới
--------
1. License input được chuyển thành password.
2. UI/log chỉ hiển thị license dạng rút gọn, ví dụ:
   KOVA-L...6VZT
3. Có nút Đổi license.
4. Thêm biến prompt mới:
   {{SKELETON_Chuong_cuoi}}

Biến {{SKELETON_Chuong_cuoi}}
-----------------------------
Biến này tự lấy riêng phần dàn khung của Chapter cuối từ output Skeleton.

Ví dụ Skeleton có:
Chapter 1
...
Chapter 2
...
Chapter 10
...

Khi prompt dùng:
{{SKELETON_Chuong_cuoi}}

Extension sẽ thay bằng riêng block:
Chapter 10
...

Nếu không đọc được số chương, extension fallback lấy block Chapter/Chương cuối cùng trong Skeleton.

Biến bổ sung
------------
{{SKELETON_CHUONG_CUOI}}      // alias uppercase, tương đương biến trên
{{SKELETON_CHAPTER_CURRENT}}  // lấy skeleton của chapter hiện tại nếu xác định được chapterNumber

Cách dùng cho prompt Chương cuối
--------------------------------
Trong prompt B6 Chương cuối, có thể dùng:

Dàn khung riêng của chương cuối:
{{SKELETON_Chuong_cuoi}}

Thay vì đưa toàn bộ:
{{SKELETON}}

Worker
------
Vẫn dùng Worker v4.1:
- /check?key=LICENSE
- /workflows?key=LICENSE

KV:
- license:KOVA-LIC-...
- workflow:FE-Stories
- workflow:HT-Stories
- workflow:VH-Stories

version.json nếu dùng GitHub public cho update:
{
  "version": "4.1.1",
  "notes": "Masked license input and added {{SKELETON_Chuong_cuoi}} variable.",
  "download_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant/raw/main/KOVA_Content_Assistant_Extension_v4_1_1.zip",
  "repo_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant"
}


v4.1.3
------
Fix lỗi không lưu license và tối ưu UI license:
- Lưu license ổn định vào storage.
- Sau khi lưu, ô nhập license tự ẩn.
- Chỉ hiển thị license rút gọn.
- Có nút Xóa license để xóa license lưu trên máy.
- Không log full license.

version.json:
{
  "version": "4.1.3",
  "notes": "Fixed license saving and stable hidden license UX.",
  "download_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant/raw/main/KOVA_Content_Assistant_Extension_v4_1_3.zip",
  "repo_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant"
}


v4.1.4
------
Fix biến không được thay thế trong prompt:

{{SKELETON_Chuong_cuoi}}
{{SKELETON_CHUONG_CUOI}}
{{SKELETON_CHAPTER_CURRENT}}

Cách hoạt động:
- Lấy output B2 Skeleton.
- Tìm Chapter/Chương/Phần cuối theo tổng số chương.
- Nếu không tìm được theo số chương, fallback lấy block chapter cuối cùng trong Skeleton.

version.json:
{
  "version": "4.1.4",
  "notes": "Fixed {{SKELETON_Chuong_cuoi}} variable replacement.",
  "download_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant/raw/main/KOVA_Content_Assistant_Extension_v4_1_4.zip",
  "repo_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant"
}


v4.1.5
------
Fix lỗi số thứ tự ở bước Chương tiếp theo.

Đã chuẩn hóa:
- {{CHAPTER_NUMBER}} luôn khớp với chương đang viết.
- {{SKELETON_CHAPTER_CURRENT}} lấy đúng dàn ý của chương đang viết.
- Output chapter lưu đúng số chương.
- Tab Chương tiếp hiển thị rõ số chương tiếp theo.
- Auto Full ghi log: Đang viết chương n/tổng.

version.json:
{
  "version": "4.1.5",
  "notes": "Fixed chapter numbering for next chapter step.",
  "download_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant/raw/main/KOVA_Content_Assistant_Extension_v4_1_5.zip",
  "repo_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant"
}


v4.1.6
------
Tối ưu Export TXT cho Voice Over.

Quy tắc khi export:
- Xóa dòng trống.
- Nhiều khoảng trắng → 1 khoảng trắng.
- — → ", "
- – → ", "
- … → ", "
- • → xóa
- " → xóa
- “ → xóa
- ” → xóa
- - → 1 khoảng trắng

Lưu ý:
- Nội dung trong giao diện vẫn giữ nguyên để dễ sửa.
- Chỉ file TXT export ra mới được làm sạch cho Voice Over.

version.json:
{
  "version": "4.1.6",
  "notes": "Optimized TXT export for Voice Over.",
  "download_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant/raw/main/KOVA_Content_Assistant_Extension_v4_1_6.zip",
  "repo_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant"
}


v4.1.9 stable
-------------
Bản này dựng từ nền v4.1.6 đang chạy ổn.

Không sửa core automation.
Chỉ override riêng phần Export TXT sau khi trang load.

Fix Export TXT:
- Xóa dòng chỉ có số chương như 4, 5, 10.
- Xóa heading chương như Chapter 4, Chương 4, Part 4, Phần 4.
- Xử lý cả dấu ba chấm ASCII "..." → ", ".
- Giữ xử lý Voice Over từ v4.1.6:
  — → ", "
  – → ", "
  … → ", "
  • → xóa
  " “ ” → xóa
  - → khoảng trắng
- Thêm nút Export Original TXT an toàn.

version.json:
{
  "version": "4.1.9",
  "notes": "Stable build from v4.1.6. Safe export-only patch: cleaner Voice Over TXT, remove chapter markers, handle ..., and add Original TXT export.",
  "download_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant/raw/main/KOVA_Content_Assistant_Extension_v4_1_9.zip",
  "repo_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant"
}


v4.1.9 filename patch
---------------------
Chỉ đổi tên file Export TXT:
- Trước: FE_001_voiceover_clean.txt
- Sau: FE_001.txt

Không thay đổi core automation hoặc quy tắc làm sạch nội dung.


v4.2.0
------
Giữ nguyên toàn bộ logic ổn định của bản trước.

Thay đổi:
- Tăng version lên 4.2.0 để hệ thống update nhận diện bản mới.
- Tên file Export TXT chỉ còn tên project.
  Ví dụ: FE_001.txt
- Không thay đổi core automation, workflow hoặc quy tắc làm sạch.


v4.2.1
------
Fix triệt để tên file Export TXT.

Trước:
FE_001_voiceover_clean.txt

Sau:
FE_001.txt

Đã xóa cả đoạn override cũ ở cuối sidebar.js.
Không thay đổi workflow, automation hoặc nội dung export.
