KOVA Content Assistant Extension v3.0
=====================================

Bản v3.0 là bản Workflow Builder.

Mục tiêu
--------
Dùng chung 1 extension cho nhiều dự án có quy trình content khác nhau hoàn toàn.

Khác v2.x
---------
v2.x:
- Nhiều Prompt Profile
- Nhưng vẫn cùng logic B1→B7

v3.0:
- Nhiều Workflow Profile
- Mỗi workflow tự định nghĩa:
  + Có bao nhiêu bước
  + Tên từng bước
  + Prompt từng bước
  + Output lưu vào đâu
  + Auto Review chạy bước nào
  + Auto Full chạy theo kiểu nào
  + Export TXT theo kiểu nào

Workflow mặc định
-----------------
1. FE Stories Workflow
   - Auto Review: analysis → skeleton → summary
   - Auto Full: chapter1 → nextChapter loop → finalChapter
   - Export: chapters_only_clean

2. Simple Script Workflow
   - Idea analysis → outline → script
   - Export: all_outputs_clean

Cách dùng
---------
1. Chọn Workflow Profile.
2. Nhập Tiêu đề/Input/Ghi chú.
3. Bấm Auto Review hoặc chạy từng bước.
4. Nếu workflow có Auto Full thì bấm Auto Full.
5. Export TXT.

Tạo workflow mới
----------------
Có 3 cách:
1. Tạo workflow mới từ Simple Script.
2. Nhân bản workflow hiện tại rồi sửa.
3. Bấm Sửa JSON để sửa trực tiếp Workflow JSON.

Biến prompt hỗ trợ
------------------
{{NEW_TITLE}}
{{ORIGINAL_SCRIPT}}
{{EXTRA_NOTES}}
{{ANALYSIS}}
{{SKELETON}}
{{SUMMARY}}
{{DE_XUAT_MOI}}
{{SEO_KEYWORDS}}
{{CHAPTERS}}
{{CHAPTER_NUMBER}}
{{CHAPTER_COUNT}}
{{OUTPUT:stepId}}
{{CHAPTER:1}}

Lưu ý
-----
- v3.0 vẫn giữ Check Update từ GitHub.
- Prompt/workflow đã sửa được lưu trong chrome.storage.local.
- Export JSON sẽ backup toàn bộ workflow và project.
- Khi update, không xóa extension cũ nếu muốn giữ storage.
