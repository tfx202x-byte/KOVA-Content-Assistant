const EXT_VERSION = "4.1.6";
const STORAGE_KEY = "kovaContentAssistantV3";
const OLD_KEYS = ["kovaContentAssistantV2", "kovaProjectV14", "kovaProjectV11", "kovaProject"];

const UPDATE_INFO_URL = "https://raw.githubusercontent.com/tfx202x-byte/KOVA-Content-Assistant/main/version.json";
const UPDATE_REPO_URL = "https://github.com/tfx202x-byte/KOVA-Content-Assistant";
const WORKFLOW_API_URL = "https://kova-workflow-api.tfx202x.workers.dev";

const FE_WORKFLOW = {
  id: "local_placeholder",
  name: "Local Placeholder - Sync Required",
  version: "4.0",
  description: "Workflow mặc định an toàn. Hãy nhập user và bấm Sync Workflows để lấy workflow được cấp quyền.",
  autoReviewSteps: ["notice"],
  export: { mode: "all_outputs_clean" },
  steps: [
    {
      id: "notice",
      name: "Hướng dẫn",
      outputKey: "notice",
      saveTo: "outputs",
      prompt: "Bạn chưa sync workflow từ server. Hãy nhập User key, bấm Kiểm tra quyền, sau đó bấm Sync Workflows."
    }
  ]
};

const SIMPLE_WORKFLOW = {
  id: "simple_script",
  name: "Simple Script Workflow",
  version: "3.0",
  description: "Generic workflow for projects that do not need chapters.",
  autoReviewSteps: ["idea", "outline"],
  export: { mode: "all_outputs_clean" },
  steps: [
    {
      id: "idea",
      name: "B1 Idea Analysis",
      saveTo: "outputs",
      outputKey: "idea",
      prompt: `Analyze this topic/input and propose the strongest content angle.

TOPIC:
{{NEW_TITLE}}

INPUT:
{{ORIGINAL_SCRIPT}}

NOTES:
{{EXTRA_NOTES}}`
    },
    {
      id: "outline",
      name: "B2 Outline",
      saveTo: "outputs",
      outputKey: "outline",
      prompt: `Create a clear outline based on this analysis:

{{OUTPUT:idea}}`
    },
    {
      id: "script",
      name: "B3 Full Script",
      saveTo: "outputs",
      outputKey: "script",
      prompt: `Write the full script based on this outline:

{{OUTPUT:outline}}

Requirements:
- No headings
- No meta commentary
- Start directly with the script`
    }
  ]
};



let state = freshState();
let isRunning = false;
let stopRequested = false;

function clone(obj) {
  return JSON.parse(JSON.stringify(obj));
}

function freshState(workflows, activeWorkflowId) {
  const wf = workflows || {
    [FE_WORKFLOW.id]: clone(FE_WORKFLOW),
    [SIMPLE_WORKFLOW.id]: clone(SIMPLE_WORKFLOW)
  };
  const active = activeWorkflowId && wf[activeWorkflowId] ? activeWorkflowId : Object.keys(wf)[0];
  return {
    appVersion: EXT_VERSION,
    projectCode: "KOVA-" + new Date().toISOString().slice(11,19).replaceAll(":",""),
    newTitle: "",
    originalScript: "",
    extraNotes: "",
    totalChapterCount: "",
    nextChapterNumber: 2,
    activeWorkflowId: active,
    activeOutput: "workflow:" + active,
    outputs: {},
    extracted: { deXuatMoi: "", seoKeywords: "" },
    chapters: {},
    workflows: wf,
    cloudUser: "",
    cloudSync: {
      lastSyncedAt: "",
      lastStatus: "",
      apiUrl: WORKFLOW_API_URL
    }
  };
}

const $ = id => document.getElementById(id);

function maskLicense(key) {
  key = String(key || "");
  if (!key) return "";
  if (key.length <= 8) return "****";
  return key.slice(0, 6) + "..." + key.slice(-4);
}


function defaultWorkflows() {
  return {
    [FE_WORKFLOW.id]: clone(FE_WORKFLOW),
    [SIMPLE_WORKFLOW.id]: clone(SIMPLE_WORKFLOW)
  };
}

function ensureValidWorkflows() {
  if (!state.workflows || typeof state.workflows !== "object") {
    state.workflows = defaultWorkflows();
  }

  for (const [id, wf] of Object.entries(state.workflows)) {
    if (!wf || typeof wf !== "object" || !wf.id || !Array.isArray(wf.steps)) {
      delete state.workflows[id];
    }
  }

  if (!Object.keys(state.workflows).length) {
    state.workflows = defaultWorkflows();
  }

  if (!state.activeWorkflowId || !state.workflows[state.activeWorkflowId]) {
    state.activeWorkflowId = Object.keys(state.workflows)[0];
  }

  return state.workflows;
}

async function restoreDefaultWorkflows() {
  if (!confirm("Khôi phục workflow mặc định? Workflow cloud/local hiện có sẽ được giữ nguyên nếu ID khác. FE/Simple mặc định sẽ được ghi lại.")) return;
  state.workflows = Object.assign({}, state.workflows || {}, defaultWorkflows());
  ensureValidWorkflows();
  await saveRaw();
  renderAll();
  log("Đã khôi phục workflow mặc định.");
}

function currentWorkflow() {
  ensureValidWorkflows();
  return state.workflows[state.activeWorkflowId];
}

function currentSteps() {
  return currentWorkflow().steps || [];
}

function stepById(id) {
  return currentSteps().find(s => s.id === id);
}

function log(msg) {
  const el = $("log");
  const t = new Date().toLocaleTimeString("vi-VN");
  el.textContent += `[${t}] ${msg}\n`;
  el.scrollTop = el.scrollHeight;
}

function wc(text) {
  const m = (text || "").trim().match(/\S+/g);
  return m ? m.length : 0;
}

function setRunning(value) {
  isRunning = value;
  document.querySelectorAll("#runButtons button, #btnCheck, #btnNewProject").forEach(btn => {
    if (btn) btn.disabled = value;
  });
}

function syncInputs() {
  state.projectCode = $("projectCode").value.trim();
  state.newTitle = $("newTitle").value.trim();
  state.originalScript = $("originalScript").value.trim();
  state.extraNotes = $("extraNotes").value.trim();
  state.totalChapterCount = $("totalChapterCount").value.trim();
  state.nextChapterNumber = getCurrentNextChapterNumber();
  state.appVersion = EXT_VERSION;
}

function currentOutputValue() {
  return { key: $("outputBox").dataset.outputKey || state.activeOutput, value: $("outputBox").value };
}

function saveVisibleOutput() {
  const { key, value } = currentOutputValue();
  if (!key) return;

  if (key.startsWith("output:")) {
    state.outputs[key.slice(7)] = value;
  } else if (key.startsWith("chapter:")) {
    state.chapters[key.slice(8)] = value;
  }
}

async function saveRaw() {
  state.appVersion = EXT_VERSION;
  await chrome.storage.local.set({ [STORAGE_KEY]: state });
}

async function saveAllFromUI() {
  syncInputs();
  saveVisibleOutput();
  await saveRaw();
}

async function loadState() {
  const keys = [STORAGE_KEY, ...OLD_KEYS];
  const data = await chrome.storage.local.get(keys);
  const loaded = data[STORAGE_KEY] || data.kovaContentAssistantV2 || data.kovaProjectV14 || data.kovaProjectV11 || data.kovaProject;

  if (loaded) {
    let workflows = loaded.workflows || null;

    // migrate v2 prompt profiles to workflows
    if (!workflows && loaded.promptProfiles) {
      workflows = {};
      for (const [name, prompts] of Object.entries(loaded.promptProfiles)) {
        const wf = clone(FE_WORKFLOW);
        wf.id = name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "") || "workflow";
        wf.name = name;
        wf.steps.forEach(step => {
          if (prompts[step.id]) step.prompt = prompts[step.id];
          if (step.id === "nextChapter" && prompts.nextChapter) step.prompt = prompts.nextChapter;
        });
        workflows[wf.id] = wf;
      }
    }

    if (!workflows) {
      workflows = {
        [FE_WORKFLOW.id]: clone(FE_WORKFLOW),
        [SIMPLE_WORKFLOW.id]: clone(SIMPLE_WORKFLOW)
      };
    }

    const active = loaded.activeWorkflowId && workflows[loaded.activeWorkflowId]
      ? loaded.activeWorkflowId
      : Object.keys(workflows)[0];

    state = Object.assign(freshState(workflows, active), loaded);
    state.workflows = workflows;
    state.activeWorkflowId = active;
    state.outputs = Object.assign({}, loaded.outputs || {});
    state.chapters = Object.assign({}, loaded.chapters || {});
    state.extracted = Object.assign({ deXuatMoi: "", seoKeywords: "" }, loaded.extracted || {});
    state.cloudSync = Object.assign({
      lastSyncedAt: "",
      lastStatus: "",
      apiUrl: WORKFLOW_API_URL
    }, loaded.cloudSync || {});
    ensureValidWorkflows();
    state.cloudUser = loaded.cloudUser || state.cloudUser || "";
    state.appVersion = EXT_VERSION;
  } else {
    state = freshState();
    ensureValidWorkflows();
  }

  await saveRaw();
  renderAll();
  log(`Extension v${EXT_VERSION} sẵn sàng. Worker/KV Access Control đã bật. Worker/KV Access Control đã bật.`);
}

function renderAll() {
  ensureValidWorkflows();
  if ($("cloudUser")) $("cloudUser").value = state.cloudUser || "";
  $("projectCode").value = state.projectCode || "";
  $("newTitle").value = state.newTitle || "";
  $("originalScript").value = state.originalScript || "";
  $("extraNotes").value = state.extraNotes || "";
  $("totalChapterCount").value = state.totalChapterCount || "";
  $("nextChapterNumber").value = state.nextChapterNumber || 2;

  renderWorkflowSelect();
  renderCloudWorkflowStatus();
  renderRunButtons();
  renderTabs();
  renderOutput();
  renderStepSelect();
}


function renderCloudWorkflowStatus() {
  const el = $("cloudWorkflowStatus");
  if (!el) return;

  const sync = state.cloudSync || {};
  const time = sync.lastSyncedAt ? new Date(sync.lastSyncedAt).toLocaleString("vi-VN") : "chưa sync";
  const status = sync.lastStatus || "Chưa sync.";
  const user = state.cloudUser || "chưa nhập license";
  el.textContent = `${status} · License: ${maskLicense(user)} · Lần sync: ${time}`;
}

function renderAccessStatus(text) {
  const el = $("accessStatus");
  if (!el) return;
  el.textContent = text || `License hiện tại: ${state.cloudUser || "chưa nhập"}`;
}


function normalizeWorkflowFromCloud(raw, fallbackId = "") {
  if (!raw || typeof raw !== "object") throw new Error("Workflow JSON không hợp lệ.");

  const wf = clone(raw);
  wf.id = String(wf.id || fallbackId || wf.name || "").toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_|_$/g, "");

  if (!wf.id) throw new Error("Workflow thiếu id.");
  if (!wf.name) wf.name = wf.id;
  if (!Array.isArray(wf.steps)) throw new Error(`Workflow ${wf.name} thiếu steps[].`);

  // ensure minimal fields
  wf.version = wf.version || "cloud";
  wf.source = "cloud";
  wf.cloudUpdatedAt = new Date().toISOString();

  return wf;
}

async function fetchJsonNoCache(url) {
  const res = await fetch(url + (url.includes("?") ? "&" : "?") + "t=" + Date.now(), { cache: "no-store" });
  if (!res.ok) throw new Error(`Không đọc được ${url}`);
  return await res.json();
}

async function fetchJsonNoCacheVerbose(url) {
  log("FETCH: " + url);
  const fullUrl = url + (url.includes("?") ? "&" : "?") + "t=" + Date.now();
  const res = await fetch(fullUrl, { cache: "no-store" });
  log(`FETCH STATUS ${res.status}: ${url}`);
  if (!res.ok) {
    let body = "";
    try { body = await res.text(); } catch (_) {}
    throw new Error(`HTTP ${res.status} khi đọc ${url}${body ? " · " + body.slice(0, 200) : ""}`);
  }
  try {
    return await res.json();
  } catch (e) {
    throw new Error(`JSON parse lỗi tại ${url}: ${e.message}`);
  }
}

function normalizeWorkerWorkflowItem(item) {
  if (!item || item.ok !== true || !item.workflow) {
    throw new Error(item?.error || `Workflow không hợp lệ: ${item?.name || "unknown"}`);
  }
  return normalizeWorkflowFromCloud(item.workflow, item.name || item.workflow.id || "workflow");
}

function forceApplyWorkerWorkflow(wf, apiName) {
  if (!wf || !wf.id || !Array.isArray(wf.steps)) {
    throw new Error("Workflow JSON thiếu id hoặc steps[].");
  }

  const existed = !!state.workflows[wf.id];

  state.workflows[wf.id] = Object.assign({}, wf, {
    id: wf.id,
    name: wf.name || wf.id,
    steps: wf.steps,
    autoReviewSteps: Array.isArray(wf.autoReviewSteps) ? wf.autoReviewSteps : [],
    autoFullScript: wf.autoFullScript || null,
    export: wf.export || { mode: "all_outputs_clean" },
    source: "worker",
    apiName: apiName || wf.id,
    cloudUser: state.cloudUser || "",
    cloudSyncedAt: new Date().toISOString()
  });

  return existed ? "updated" : "added";
}

function purgeUnauthorizedWorkerWorkflows(allowedWorkflowIds) {
  const allowed = new Set(allowedWorkflowIds || []);
  for (const [id, wf] of Object.entries(state.workflows || {})) {
    if (wf && wf.source === "worker" && !allowed.has(id)) {
      delete state.workflows[id];
      log("Gỡ workflow không còn quyền: " + (wf.name || id));
    }
  }
}

async function checkWorkflowAccess() {
  try {
    const user = ($("cloudUser")?.value || state.cloudUser || "").trim();
    if (!user) return alert("Bạn cần nhập License key trước.");

    state.cloudUser = user;
    const data = await fetchJsonNoCacheVerbose(`${WORKFLOW_API_URL}/check?key=${encodeURIComponent(user)}`);

    if (!data.ok) throw new Error(data.error || "Không kiểm tra được quyền.");

    await saveRaw();
    renderAccessStatus(`License: ${maskLicense(user)} · ${data.name || user} · Được cấp: ${(data.workflows || []).join(", ") || "không có workflow"}`);
    log(`Kiểm tra quyền OK: ${maskLicense(user)} · ${(data.workflows || []).join(", ")}`);
  } catch (e) {
    renderAccessStatus("Lỗi kiểm tra quyền: " + e.message);
    log("LỖI kiểm tra quyền: " + e.message);
    alert(e.message);
  }
}

async function syncCloudWorkflows() {
  const btn = $("btnSyncCloudWorkflows");
  try {
    ensureValidWorkflows();

    const user = ($("cloudUser")?.value || state.cloudUser || "").trim();
    if (!user) return alert("Bạn cần nhập License key trước khi sync.");

    state.cloudUser = user;

    if (btn) btn.disabled = true;
    $("cloudWorkflowStatus").textContent = "Đang sync workflows từ Worker/KV...";
    log("=== Bắt đầu Worker Sync ===");
    log("LICENSE: " + user);

    const data = await fetchJsonNoCacheVerbose(`${WORKFLOW_API_URL}/workflows?key=${encodeURIComponent(user)}`);
    if (!data.ok) throw new Error(data.error || "Worker trả lỗi.");

    const items = Array.isArray(data.workflows) ? data.workflows : [];
    if (!items.length) throw new Error("License này chưa được cấp workflow nào.");

    const selectedBefore = state.activeWorkflowId;
    let added = 0;
    let updated = 0;
    const changed = [];
    const errors = [];
    const allowedIds = [];

    for (const item of items) {
      try {
        const wf = normalizeWorkerWorkflowItem(item);
        const result = forceApplyWorkerWorkflow(wf, item.name);
        allowedIds.push(wf.id);

        if (result === "updated") updated += 1;
        else added += 1;

        changed.push(`${wf.name || wf.id} (${wf.id})`);
        log(`${result === "updated" ? "CẬP NHẬT" : "THÊM"}: ${wf.name || wf.id} · ${wf.id}`);
      } catch (e) {
        errors.push(e.message);
        log("LỖI workflow từ Worker: " + e.message);
      }
    }

    purgeUnauthorizedWorkerWorkflows(allowedIds);
    ensureValidWorkflows();

    if (selectedBefore && state.workflows[selectedBefore]) {
      state.activeWorkflowId = selectedBefore;
    } else if (allowedIds.length && state.workflows[allowedIds[0]]) {
      state.activeWorkflowId = allowedIds[0];
    } else {
      state.activeWorkflowId = Object.keys(state.workflows)[0];
    }

    state.activeOutput = "workflow:" + state.activeWorkflowId;

    state.cloudSync = {
      lastSyncedAt: new Date().toISOString(),
      lastStatus: `Sync xong: thêm ${added}, cập nhật ${updated}${errors.length ? ", lỗi " + errors.length : ""}`,
      apiUrl: WORKFLOW_API_URL,
      user,
      changed,
      errors
    };

    await saveRaw();
    renderAll();
    renderAccessStatus(`License: ${maskLicense(user)} · ${(data.name || user)} · Được cấp: ${items.map(x => x.name).join(", ")}`);

    const selectedStep = $("stepSelect")?.value;
    if (selectedStep) {
      const step = stepById(selectedStep);
      if (step && $("promptBox")) $("promptBox").value = step.prompt || "";
    }

    const msg = state.cloudSync.lastStatus + (changed.length ? " · " + changed.join(", ") : "");
    $("cloudWorkflowStatus").textContent = msg;
    log(msg);
    log("=== Kết thúc Worker Sync ===");

    if (errors.length) alert("Sync xong nhưng có lỗi:\\n" + errors.join("\\n"));
  } catch (e) {
    ensureValidWorkflows();
    state.cloudSync = Object.assign(state.cloudSync || {}, {
      lastSyncedAt: new Date().toISOString(),
      lastStatus: "Sync lỗi: " + e.message
    });
    await saveRaw();
    renderAll();
    renderAccessStatus("Lỗi sync: " + e.message);
    log("LỖI Worker Sync: " + e.message);
    alert(e.message);
  } finally {
    if (btn) btn.disabled = false;
  }
}


function renderWorkflowSelect() {
  ensureValidWorkflows();
  const sel = $("workflowSelect");
  sel.innerHTML = "";
  Object.values(state.workflows || {}).forEach(wf => {
    const opt = document.createElement("option");
    opt.value = wf.id;
    opt.textContent = wf.name || wf.id;
    sel.appendChild(opt);
  });
  sel.value = state.activeWorkflowId;
}


function formatList(value) {
  if (Array.isArray(value)) return value.map(x => "- " + x).join("\n");
  return String(value || "");
}

function renderRunButtons() {
  const box = $("runButtons");
  box.innerHTML = "";

  addRunButton(box, "Auto Review", "primary", () => autoReview());
  addRunButton(box, "Auto Full", "primary2", () => autoFull());

  currentSteps().forEach(step => {
    addRunButton(box, step.name || step.id, "", () => runStep(step.id));
  });

  addRunButton(box, "Dừng auto", "light", () => {
    stopRequested = true;
    log("Đã yêu cầu dừng auto sau tác vụ hiện tại.");
  });
}

function addRunButton(container, text, cls, onclick) {
  const b = document.createElement("button");
  b.type = "button";
  b.textContent = text;
  if (cls) b.className = cls;
  b.onclick = onclick;
  container.appendChild(b);
}

function renderTabs() {
  const tabs = $("tabs");
  tabs.innerHTML = "";

  const wf = currentWorkflow();
  addTab(tabs, "workflow:" + wf.id, "Workflow");

  currentSteps().forEach(step => {
    let key;
    let label = step.name || step.id;

    if (step.saveTo === "chapter") {
      const n = resolveChapterNumber(step);

      // For dynamic "Chương tiếp", show the next chapter number clearly.
      if (isDynamicChapterStep(step)) {
        label = `${label} (${n})`;
      }

      if (isFinalChapterStep(step)) {
        label = `${label} (${n})`;
      }

      key = `chapter:${n}`;
    } else {
      key = `output:${step.outputKey || step.id}`;
    }

    addTab(tabs, key, label);
  });

  Object.keys(state.chapters || {}).map(Number).sort((a,b)=>a-b).forEach(n => {
    addTab(tabs, `chapter:${n}`, `Ch.${n}`);
  });
}

function addTab(container, key, name) {
  const b = document.createElement("button");
  b.type = "button";
  b.className = "tab" + (state.activeOutput === key ? " active" : "");
  b.textContent = name;
  b.onclick = async e => {
    e.preventDefault();
    e.stopPropagation();
    syncInputs();
    saveVisibleOutput();
    state.activeOutput = key;
    await saveRaw();
    renderTabs();
    renderOutput();
  };
  container.appendChild(b);
}

function getOutputText(key) {
  if (!key) return "";
  if (key.startsWith("output:")) return state.outputs[key.slice(7)] || "";
  if (key.startsWith("chapter:")) return state.chapters[key.slice(8)] || "";
  if (key.startsWith("workflow:")) return JSON.stringify(currentWorkflow(), null, 2);
  return "";
}

function getOutputTitle(key) {
  if (!key) return "Output";
  if (key.startsWith("output:")) {
    const id = key.slice(7);
    const step = currentSteps().find(s => (s.outputKey || s.id) === id);
    return step?.name || id;
  }
  if (key.startsWith("chapter:")) return "Chương " + key.slice(8);
  if (key.startsWith("workflow:")) return "Workflow JSON";
  return key;
}

function renderOutput() {
  const key = state.activeOutput || ("workflow:" + currentWorkflow().id);
  const text = getOutputText(key);
  $("activeTitle").textContent = getOutputTitle(key);
  $("outputBox").dataset.outputKey = key;
  $("outputBox").value = text;
  $("wordCount").textContent = `${wc(text)} từ`;
}

function renderStepSelect() {
  const sel = $("stepSelect");
  sel.innerHTML = "";
  currentSteps().forEach(step => {
    const opt = document.createElement("option");
    opt.value = step.id;
    opt.textContent = step.name || step.id;
    sel.appendChild(opt);
  });
  const first = currentSteps()[0];
  if (first) {
    sel.value = first.id;
    $("promptBox").value = first.prompt || "";
  }
}

function normalize(text) {
  return (text || "").replace(/\r/g, "\n").replace(/\u00A0/g, " ").replace(/[ \t]+/g, " ");
}

function lineIndex(lines, patterns, from = 0) {
  for (let i = from; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    if (patterns.some(p => p.test(line))) return i;
  }
  return -1;
}

function blockByHeading(text, startPatterns, endPatterns) {
  const lines = normalize(text).split("\n");
  const s = lineIndex(lines, startPatterns);
  if (s === -1) return "";
  let e = lines.length;
  for (let i = s + 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    if (endPatterns.some(p => p.test(line))) {
      e = i;
      break;
    }
  }
  return lines.slice(s + 1, e).join("\n").trim();
}

function extractFromAnalysis() {
  const text = state.outputs.analysis || "";
  const deXuat = blockByHeading(
    text,
    [/^(?:#{1,6}\s*)?(?:\*\*)?\s*(?:iii|3|ba)?\s*[\.\)]?\s*điểm\s*yếu\s*(?:và|&)\s*cách\s*cải\s*thiện\s*(?:\*\*)?\s*:?$/i],
    [/^(?:#{1,6}\s*)?(?:\*\*)?\s*(?:iv|4|bốn)?\s*[\.\)]?\s*seo\s*keywords?\s*(?:\*\*)?\s*:?$/i, /kết\s*luận/i]
  );
  const seo = blockByHeading(
    text,
    [/^(?:#{1,6}\s*)?(?:\*\*)?\s*(?:iv|4|bốn)?\s*[\.\)]?\s*seo\s*keywords?\s*(?:\*\*)?\s*:?$/i],
    [/^(?:#{1,6}\s*)?(?:\*\*)?\s*(?:v|5|năm)?\s*[\.\)]?\s*kết\s*luận\s*(?:\*\*)?\s*:?$/i]
  );
  state.extracted.deXuatMoi = deXuat || "[Không tách được mục Điểm yếu và cách cải thiện từ B1.]";
  state.extracted.seoKeywords = seo || "[Không tách được mục SEO keywords từ B1.]";
  return state.extracted;
}

function parseChapterCount(skeleton) {
  const text = skeleton || "";
  const patterns = [
    /Suggested\s+Chapter\s+Count\s*[:：\-]?\s*(\d{1,2})/i,
    /Suggested\s+Chapters?\s*[:：\-]?\s*(\d{1,2})/i,
    /Chapter\s+Count\s*[:：\-]?\s*(\d{1,2})/i,
    /Số\s+chương\s+(?:đề\s+xuất|gợi\s+ý|suggested)?\s*[:：\-]?\s*(\d{1,2})/i,
    /Tổng\s+số\s+chương\s*[:：\-]?\s*(\d{1,2})/i
  ];
  for (const p of patterns) {
    const m = text.match(p);
    if (m && Number(m[1]) >= 2) return Number(m[1]);
  }
  const nums = [...text.matchAll(/(?:^|\n)\s*(?:#{1,6}\s*)?(?:Chapter|Chương)\s+(\d{1,2})\b/gi)].map(x => Number(x[1]));
  return nums.length ? Math.max(...nums) : null;
}

function getTotalChapterCount() {
  const manual = Number(state.totalChapterCount || $("totalChapterCount").value || 0);
  if (manual && manual >= 2) return manual;
  const skeleton = state.outputs.skeleton || state.outputs.outline || "";
  const parsed = parseChapterCount(skeleton);
  if (parsed && parsed >= 2) {
    state.totalChapterCount = String(parsed);
    $("totalChapterCount").value = String(parsed);
    return parsed;
  }
  return null;
}


function clampChapterNumber(n) {
  n = Number(n);
  const total = getTotalChapterCount();
  if (!Number.isFinite(n) || n < 1) return 1;
  if (total && n > total) return total;
  return n;
}

function getCurrentNextChapterNumber() {
  const input = $("nextChapterNumber");
  const fromInput = Number(input?.value || 0);
  const fromState = Number(state.nextChapterNumber || 0);
  const n = fromInput || fromState || 2;
  return clampChapterNumber(n);
}

function isDynamicChapterStep(step) {
  return step && step.saveTo === "chapter" && step.chapterNumber === "{{CHAPTER_NUMBER}}";
}

function isFinalChapterStep(step) {
  return step && step.saveTo === "chapter" && step.chapterNumber === "{{CHAPTER_COUNT}}";
}

function resolveChapterNumber(step, fallbackNumber) {
  const raw = step.chapterNumber;

  if (raw === "{{CHAPTER_COUNT}}") {
    const total = getTotalChapterCount();
    if (!total) return "final";
    return total;
  }

  if (raw === "{{CHAPTER_NUMBER}}") {
    const n = fallbackNumber !== undefined && fallbackNumber !== null && fallbackNumber !== ""
      ? Number(fallbackNumber)
      : getCurrentNextChapterNumber();
    return clampChapterNumber(n);
  }

  if (raw === undefined || raw === null || raw === "") {
    const n = fallbackNumber !== undefined && fallbackNumber !== null && fallbackNumber !== ""
      ? Number(fallbackNumber)
      : getCurrentNextChapterNumber();
    return clampChapterNumber(n);
  }

  const fixed = Number(raw);
  return Number.isFinite(fixed) ? clampChapterNumber(fixed) : raw;
}

function buildFullScriptOrdered() {
  const nums = Object.keys(state.chapters || {}).map(Number).filter(Number.isFinite).sort((a,b)=>a-b);
  return nums.map(n => state.chapters[String(n)]).filter(Boolean).join("\n\n");
}

function cleanChapterContent(raw) {
  let text = String(raw || "").replace(/\r/g, "\n").trim();
  text = text.replace(/^```(?:text|markdown|md)?\s*/i, "").replace(/```\s*$/i, "").trim();
  let lines = text.split("\n");
  while (lines.length && !lines[0].trim()) lines.shift();
  const junk = [
    /^\s*(?:chapter|chương)\s*\d{1,2}\b(?:\s*[-–—:.)].*)?$/i,
    /^\s*\d{1,2}\s*[\.)]?\s*$/i,
    /^\s*(?:here\s+is|here's)\s+(?:the\s+)?(?:chapter|next\s+chapter|final\s+chapter).*$/i,
    /^\s*(?:sure|certainly)[,.]?\s*(?:here\s+is|here's).*$/i,
    /^\s*(?:opening\s+hook|hook|chapter\s+title)\s*[:.]?\s*$/i,
    /^\s*title\s*[:：].*$/i
  ];
  let removed = true;
  while (removed && lines.length) {
    removed = false;
    const first = lines[0].trim();
    if (!first || junk.some(p => p.test(first))) {
      lines.shift();
      removed = true;
    }
  }
  return lines.join("\n").replace(/\n{3,}/g, "\n\n").trim();
}


function cleanForVoiceOver(text) {
  return String(text || "")
    .replace(/\r/g, "\n")
    .replace(/—/g, ", ")
    .replace(/–/g, ", ")
    .replace(/…/g, ", ")
    .replace(/•/g, "")
    .replace(/"/g, "")
    .replace(/“/g, "")
    .replace(/”/g, "")
    .replace(/-/g, " ")
    .replace(/[ \t]+/g, " ")
    .replace(/\n\s*\n+/g, "\n")
    .split("\n")
    .map(line => line.trim())
    .filter(Boolean)
    .join("\n")
    .trim();
}

function buildCleanScript() {
  const nums = Object.keys(state.chapters || {}).map(Number).filter(Number.isFinite).sort((a,b)=>a-b);
  return nums.map(n => cleanChapterContent(state.chapters[String(n)])).filter(Boolean).join("\n\n");
}


function extractFinalChapterSkeleton(skeletonText) {
  const text = String(skeletonText || "").replace(/\r/g, "\n").trim();
  if (!text) return "";

  const total = getTotalChapterCount();
  const lines = text.split("\n");

  function anyChapterHeading(line) {
    return /^\s*(?:#{1,6}\s*)?(?:\*\*)?\s*(?:Chapter|Chương|Phần|Part)\s+\d{1,2}\b/i.test(String(line || "").trim());
  }

  function headingRegex(n) {
    return new RegExp("^\\s*(?:#{1,6}\\s*)?(?:\\*\\*)?\\s*(?:Chapter|Chương|Phần|Part)\\s+" + n + "\\b(?:\\s*[:\\-–—.)].*)?$", "i");
  }

  // Prefer exact final chapter from total chapter count.
  if (total && total >= 2) {
    let start = -1;
    const rx = headingRegex(total);
    for (let i = 0; i < lines.length; i++) {
      if (rx.test(lines[i])) {
        start = i;
        break;
      }
    }
    if (start !== -1) {
      let end = lines.length;
      for (let j = start + 1; j < lines.length; j++) {
        if (anyChapterHeading(lines[j])) {
          end = j;
          break;
        }
      }
      return lines.slice(start, end).join("\n").trim();
    }
  }

  // Fallback: take the last chapter-like block.
  const starts = [];
  for (let i = 0; i < lines.length; i++) {
    if (anyChapterHeading(lines[i])) starts.push(i);
  }
  if (!starts.length) return "";
  return lines.slice(starts[starts.length - 1]).join("\n").trim();
}

function extractChapterSkeletonByNumber(skeletonText, chapterNumber) {
  const text = String(skeletonText || "").replace(/\r/g, "\n").trim();
  if (!text || !chapterNumber) return "";

  const lines = text.split("\n");
  const heading = new RegExp("^\\s*(?:#{1,6}\\s*)?(?:\\*\\*)?\\s*(?:Chapter|Chương|Phần|Part)\\s+" + chapterNumber + "\\b(?:\\s*[:\\-–—.)].*)?$", "i");
  const anyHeading = line => /^\s*(?:#{1,6}\s*)?(?:\*\*)?\s*(?:Chapter|Chương|Phần|Part)\s+\d{1,2}\b/i.test(String(line || "").trim());

  let start = -1;
  for (let i = 0; i < lines.length; i++) {
    if (heading.test(lines[i])) {
      start = i;
      break;
    }
  }
  if (start === -1) return "";

  let end = lines.length;
  for (let j = start + 1; j < lines.length; j++) {
    if (anyHeading(lines[j])) {
      end = j;
      break;
    }
  }
  return lines.slice(start, end).join("\n").trim();
}

function renderTemplate(step, chapterNumber) {
  extractFromAnalysis();
  const vars = {
    NEW_TITLE: state.newTitle || "",
    ORIGINAL_SCRIPT: state.originalScript || "",
    EXTRA_NOTES: state.extraNotes || "",
    ANALYSIS: state.outputs.analysis || "",
    SKELETON: state.outputs.skeleton || "",
    SKELETON_Chuong_cuoi: extractFinalChapterSkeleton(state.outputs.skeleton || ""),
    SKELETON_CHUONG_CUOI: extractFinalChapterSkeleton(state.outputs.skeleton || ""),
    SKELETON_CHAPTER_CURRENT: extractChapterSkeletonByNumber(state.outputs.skeleton || "", chapterNumber || state.nextChapterNumber || 1),
    SUMMARY: state.outputs.summary || "",
    DE_XUAT_MOI: state.extracted.deXuatMoi || "",
    SEO_KEYWORDS: state.extracted.seoKeywords || "",
    CHAPTERS: buildFullScriptOrdered(),
    CHAPTER_NUMBER: chapterNumber || getCurrentNextChapterNumber(),
    CURRENT_CHAPTER: chapterNumber || getCurrentNextChapterNumber(),
    NEXT_CHAPTER: getCurrentNextChapterNumber(),
    CHAPTER_COUNT: getTotalChapterCount() || "",
  };

  let prompt = step.prompt || "";
  prompt = prompt.replace(/\{\{OUTPUT:([a-zA-Z0-9_-]+)\}\}/g, (_, id) => state.outputs[id] || "");
  prompt = prompt.replace(/\{\{CHAPTER:([0-9]+)\}\}/g, (_, n) => state.chapters[n] || "");
  prompt = prompt.replace(/\{\{([A-Za-z0-9_]+)\}\}/g, (_, name) => vars[name] ?? "");
  prompt = prompt.replaceAll("{{SKELETON_Chuong_cuoi}}", vars.SKELETON_Chuong_cuoi || "");
  prompt = prompt.replaceAll("{{SKELETON_CHUONG_CUOI}}", vars.SKELETON_CHUONG_CUOI || "");
  prompt = prompt.replaceAll("{{SKELETON_CHAPTER_CURRENT}}", vars.SKELETON_CHAPTER_CURRENT || "");
  return prompt;
}

async function getChatGPTTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const active = tabs[0];
  if (active && /https:\/\/(chatgpt\.com|chat\.openai\.com)\//.test(active.url || "")) return active;
  const all = await chrome.tabs.query({ url: ["https://chatgpt.com/*", "https://chat.openai.com/*"] });
  if (all.length) return all[0];
  throw new Error("Không tìm thấy tab ChatGPT. Hãy mở đúng Project/đoạn chat trên chatgpt.com trước.");
}

async function ensureContentScript(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "KOVA_PING" });
  } catch {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
  }
}

async function pingChatGPT() {
  const tab = await getChatGPTTab();
  await ensureContentScript(tab.id);
  return chrome.tabs.sendMessage(tab.id, { type: "KOVA_PING" });
}

async function sendToChatGPT(prompt) {
  const tab = await getChatGPTTab();
  await ensureContentScript(tab.id);
  await chrome.tabs.update(tab.id, { active: true });
  const res = await chrome.tabs.sendMessage(tab.id, {
    type: "KOVA_RUN_PROMPT",
    prompt,
    options: { timeoutSec: 900, stableSec: 14 }
  });
  if (!res || !res.ok) throw new Error(res?.error || "Không nhận được output từ ChatGPT.");
  return res.answer || "";
}

async function runStep(stepId, opts = {}) {
  const step = stepById(stepId);
  if (!step) throw new Error("Không tìm thấy bước: " + stepId);

  if (!opts.internal && isRunning) {
    log("Đang chạy automation khác.");
    return;
  }
  if (!opts.internal) setRunning(true);

  try {
    syncInputs();
    await saveRaw();

    if (!state.newTitle && !state.originalScript) {
      alert("Bạn cần nhập tiêu đề/chủ đề hoặc input gốc trước.");
      return;
    }

    const chapterNo = resolveChapterNumber(step, opts.chapterNumber);
    const answer = await sendToChatGPT(renderTemplate(step, chapterNo));

    if (step.saveTo === "chapter") {
      const n = chapterNo;
      if (!n || n === "final") throw new Error("Không xác định được số chương. Hãy nhập Tổng số chương.");
      state.chapters[String(n)] = answer;

      const total = getTotalChapterCount();
      if (total && Number(n) >= total) {
        state.nextChapterNumber = total;
      } else {
        state.nextChapterNumber = Number(n) + 1;
      }

      if ($("nextChapterNumber")) $("nextChapterNumber").value = String(state.nextChapterNumber);
      state.activeOutput = `chapter:${n}`;
    } else {
      const key = step.outputKey || step.id;
      state.outputs[key] = answer;
      if (key === "analysis") extractFromAnalysis();
      if (key === "skeleton") {
        const t = parseChapterCount(answer);
        if (t) state.totalChapterCount = String(t);
      }
      state.activeOutput = `output:${key}`;
    }

    await saveRaw();
    renderAll();
    log(`Đã lưu ${step.name || step.id}: ${wc(answer)} từ.`);
  } finally {
    if (!opts.internal) setRunning(false);
  }
}

async function autoReview() {
  if (isRunning) return;
  setRunning(true);
  try {
    const steps = currentWorkflow().autoReviewSteps || [];
    if (!steps.length) {
      alert("Workflow này chưa cấu hình autoReviewSteps.");
      return;
    }
    for (const stepId of steps) {
      if (stopRequested) break;
      await runStep(stepId, { internal: true });
      await new Promise(r => setTimeout(r, 1200));
    }
    log("Đã chạy xong Auto Review. Dừng để bạn duyệt.");
  } catch (e) {
    log("LỖI Auto Review: " + e.message);
    alert(e.message);
  } finally {
    setRunning(false);
    stopRequested = false;
  }
}

async function autoFull() {
  if (isRunning) return;
  setRunning(true);

  try {
    const cfg = currentWorkflow().autoFullScript;
    if (!cfg) {
      alert("Workflow này chưa cấu hình autoFullScript.");
      return;
    }

    syncInputs();
    await saveRaw();

    const total = getTotalChapterCount();
    if (!total || total < 2) {
      alert("Không đọc được Tổng số chương. Hãy nhập tay trước khi Auto Full.");
      return;
    }

    if (Object.keys(state.chapters || {}).length) {
      const ok = confirm("Đã có chương cũ. Auto Full sẽ viết lại từ chương 1 và ghi đè chương cũ. Tiếp tục?");
      if (!ok) return;
    }

    state.chapters = {};
    state.nextChapterNumber = 2;
    if ($("nextChapterNumber")) $("nextChapterNumber").value = "2";
    stopRequested = false;
    await saveRaw();
    renderAll();

    log(`Auto Full: Chương 1 → Chương ${total}. Mỗi chương gửi prompt riêng.`);

    await runStep(cfg.chapter1Step, { chapterNumber: 1, internal: true });

    const lastMiddleChapter = cfg.finalStep ? total - 1 : total;
    for (let n = 2; n <= lastMiddleChapter; n++) {
      if (stopRequested) break;
      state.nextChapterNumber = n;
      if ($("nextChapterNumber")) $("nextChapterNumber").value = String(n);
      await saveRaw();

      log(`Đang viết chương ${n}/${total}...`);
      await runStep(cfg.loopStep, { chapterNumber: n, internal: true });
      await new Promise(r => setTimeout(r, 1800));
    }

    if (!stopRequested && cfg.finalStep) {
      state.nextChapterNumber = total;
      if ($("nextChapterNumber")) $("nextChapterNumber").value = String(total);
      await saveRaw();

      log(`Đang viết chương cuối ${total}/${total}...`);
      await runStep(cfg.finalStep, { chapterNumber: total, internal: true });
      log("Đã Auto Full xong. Có thể Export TXT.");
    } else if (!stopRequested) {
      log("Đã Auto Full xong. Có thể Export TXT.");
    }
  } catch (e) {
    log("LỖI Auto Full: " + e.message);
    alert(e.message);
  } finally {
    setRunning(false);
    stopRequested = false;
  }
}

async function checkTab() {
  try {
    const res = await pingChatGPT();
    $("statusDot").classList.toggle("ok", !!res.ok);
    $("status").textContent = res.ok
      ? `Đã kết nối: ${res.title || res.url}. Composer: ${res.hasComposer ? "OK" : "chưa thấy"} · Send: ${res.hasSendButton ? "OK" : "fallback Enter"}`
      : "Chưa kết nối.";
    log("Kiểm tra ChatGPT: " + JSON.stringify(res));
  } catch (e) {
    $("statusDot").classList.remove("ok");
    $("status").textContent = e.message;
    log("LỖI kiểm tra: " + e.message);
  }
}

function compareVersions(a, b) {
  const pa = String(a || "0").split(".").map(x => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map(x => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    if ((pa[i] || 0) > (pb[i] || 0)) return 1;
    if ((pa[i] || 0) < (pb[i] || 0)) return -1;
  }
  return 0;
}

function setUpdateUI(message, hasUpdate = false, info = null) {
  $("updateStatus").textContent = message;
  $("updateActions").classList.toggle("hidden", !hasUpdate);
  $("updateGuide").classList.toggle("hidden", !hasUpdate);
  if (hasUpdate && info) {
    $("btnDownloadUpdate").dataset.url = info.download_url || "";
    $("btnOpenRepo").dataset.url = info.repo_url || UPDATE_REPO_URL;
  }
}

async function checkForUpdates(silent = false) {
  try {
    setUpdateUI(`Đang kiểm tra update... Phiên bản hiện tại: v${EXT_VERSION}`);
    const res = await fetch(UPDATE_INFO_URL + "?t=" + Date.now(), { cache: "no-store" });
    if (!res.ok) throw new Error("Không đọc được version.json từ GitHub.");
    const info = await res.json();
    const latest = String(info.version || "").trim();
    if (!latest) throw new Error("version.json thiếu version.");
    if (compareVersions(EXT_VERSION, latest) < 0) {
      setUpdateUI(`Có bản mới: v${latest}${info.notes ? " · " + info.notes : ""}. Hiện tại: v${EXT_VERSION}`, true, info);
      log(`Có bản cập nhật mới: v${latest}`);
      return;
    }
    setUpdateUI(`Đang dùng bản mới nhất: v${EXT_VERSION}`);
    if (!silent) log("Extension đang là bản mới nhất.");
  } catch (e) {
    setUpdateUI(`Không kiểm tra được update: ${e.message}`);
    if (!silent) log("LỖI kiểm tra update: " + e.message);
  }
}

function downloadBlob(blob, name) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}

async function exportJSON() {
  await saveAllFromUI();
  downloadBlob(new Blob([JSON.stringify(state, null, 2)], { type: "application/json" }), `${state.projectCode || "kova-project"}.json`);
}

async function exportTXT() {
  saveVisibleOutput();
  syncInputs();

  const text = cleanForVoiceOver(buildCleanScript());

  if (!text) {
    alert("Chưa có kịch bản chương để export.");
    return;
  }

  const filename = `${state.projectCode || "script"}_voiceover_clean.txt`;
  const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);

  log("Đã export TXT sạch cho Voice Over: " + filename);
}

function importJSONFile(file) {
  const reader = new FileReader();
  reader.onload = async () => {
    try {
      const imported = JSON.parse(reader.result);
      state = Object.assign(freshState(), imported);
      if (!state.workflows) state.workflows = freshState().workflows;
      await saveRaw();
      renderAll();
      log("Import thành công.");
    } catch {
      alert("File JSON không hợp lệ.");
    }
  };
  reader.readAsText(file);
}

function newProject() {
  if (!confirm("Tạo project mới? Workflow hiện có sẽ được giữ.")) return;
  const workflows = state.workflows;
  const active = state.activeWorkflowId;
  state = freshState(workflows, active);
  saveRaw().then(renderAll);
}

function refreshWorkflowJsonEditor() {
  $("workflowJsonBox").value = JSON.stringify(buildWorkflowPack(currentWorkflow()), null, 2);
}


function workflowFileName(wf) {
  const base = String(wf.name || wf.id || "workflow")
    .trim()
    .replace(/[^\w\-]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
  return `${base || "workflow"}.json`;
}

function buildWorkflowPack(wf = currentWorkflow()) {
  // Workflow Pack = workflow definition, prompts, auto rules and export rules.
  // It is clean enough to upload directly to GitHub workflows/.
  const pack = clone(wf);
  pack.version = pack.version || "1.0";
  pack.updatedAt = new Date().toISOString();

  // Runtime-only metadata should not be required in cloud workflow files.
  delete pack.cloudUpdatedAt;
  delete pack.projectConfig;

  return pack;
}

function applyWorkflowPack(pack, options = {}) {
  if (!pack || typeof pack !== "object") throw new Error("Workflow pack không hợp lệ.");
  if (!pack.id || !pack.name || !Array.isArray(pack.steps)) {
    throw new Error("Workflow pack cần có id, name, steps[].");
  }

  const wf = clone(pack);

  delete wf.projectConfig;

  wf.updatedAt = wf.updatedAt || new Date().toISOString();
  wf.source = options.source || wf.source || "local";

  state.workflows[wf.id] = wf;
  state.activeWorkflowId = wf.id;
  state.activeOutput = "workflow:" + wf.id;

  return wf;
}

async function saveCurrentWorkflowPack() {
  syncInputs();
  saveVisibleOutput();

  const wf = currentWorkflow();
  wf.updatedAt = new Date().toISOString();
  state.workflows[wf.id] = wf;
  await saveRaw();

  const steps = Array.isArray(wf.steps) ? wf.steps.length : 0;
  const msg = `Đã lưu toàn bộ workflow: ${wf.name || wf.id} · ${steps} bước · ${new Date(wf.updatedAt).toLocaleString("vi-VN")}`;
  $("workflowPackStatus").textContent = msg;
  log(msg);
}

async function exportCurrentWorkflowPack() {
  await saveCurrentWorkflowPack();

  const pack = buildWorkflowPack(currentWorkflow());
  const blob = new Blob([JSON.stringify(pack, null, 2)], { type: "application/json;charset=utf-8" });
  downloadBlob(blob, workflowFileName(pack));
  log("Đã export Workflow JSON: " + workflowFileName(pack));
}

function importWorkflowPackFile(file) {
  const reader = new FileReader();
  reader.onload = async () => {
    try {
      const pack = JSON.parse(reader.result);
      applyWorkflowPack(pack, { source: "imported" });
      await saveRaw();
      renderAll();
      log("Import Workflow Pack thành công: " + currentWorkflow().name);
    } catch (e) {
      alert("Workflow JSON không hợp lệ: " + e.message);
    }
  };
  reader.readAsText(file);
}

async function duplicateWorkflowForProject() {
  const wf = currentWorkflow();
  const name = prompt("Tên dự án/workflow mới:", (state.projectConfig?.projectName || wf.name || "New Project") + " Copy");
  if (!name) return;

  const id = name.toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_|_$/g, "") || "workflow";

  if (state.workflows[id]) {
    alert("Workflow này đã tồn tại.");
    return;
  }

  const newWf = clone(wf);
  newWf.id = id;
  newWf.name = name;
  newWf.source = "local";
  newWf.updatedAt = new Date().toISOString();

  state.workflows[id] = newWf;
  state.activeWorkflowId = id;
  state.activeOutput = "workflow:" + id;

  await saveRaw();
  renderAll();
  log("Đã nhân bản workflow cho dự án mới: " + name);
}

async function saveCurrentStepPrompt() {
  const step = stepById($("stepSelect").value);
  if (!step) return;
  step.prompt = $("promptBox").value;
  currentWorkflow().updatedAt = new Date().toISOString();
  await saveRaw();
  log("Đã lưu prompt cho bước: " + (step.name || step.id));
}

async function saveStepPromptAndWorkflow() {
  await saveCurrentStepPrompt();
  await saveCurrentWorkflowPack();
}

chrome.runtime.onMessage.addListener(message => {
  if (message?.type === "KOVA_PROGRESS") {
    if (message.status) log(message.status);
    if (message.words) log(`ChatGPT đang trả lời... ${message.words} từ`);
  }
});

document.addEventListener("input", async e => {
  if (["projectCode", "newTitle", "originalScript", "extraNotes", "nextChapterNumber", "totalChapterCount"].includes(e.target.id)) {
    syncInputs();
    await saveRaw();
  }
  if (e.target.id === "outputBox") {
    $("wordCount").textContent = `${wc($("outputBox").value)} từ`;
    saveVisibleOutput();
    await saveRaw();
  }
});

document.addEventListener("DOMContentLoaded", async () => {
  await loadState();

  $("outputBox").addEventListener("click", e => e.stopPropagation());

  $("btnCheck").onclick = checkTab;
  $("btnNewProject").onclick = newProject;
  $("btnSaveInputs").onclick = async () => { await saveAllFromUI(); log("Đã lưu input/output hiện tại."); };
  $("btnExportJson").onclick = exportJSON;
  $("btnImportJson").onclick = () => $("importFile").click();
  $("importFile").onchange = e => e.target.files[0] && importJSONFile(e.target.files[0]);

  $("btnCheckUpdate").onclick = () => checkForUpdates(false);
  $("btnDownloadUpdate").onclick = () => {
    const url = $("btnDownloadUpdate").dataset.url;
    if (!url) return alert("version.json chưa có download_url.");
    chrome.tabs.create({ url });
  };
  $("btnOpenRepo").onclick = () => chrome.tabs.create({ url: $("btnOpenRepo").dataset.url || UPDATE_REPO_URL });
  setTimeout(() => checkForUpdates(true), 1200);

  $("btnSaveCloudUser").onclick = async () => {
    state.cloudUser = ($("cloudUser").value || "").trim();
    await saveRaw();
    renderAccessStatus("Đã lưu license: " + (state.cloudUser || "chưa nhập"));
    log("Đã lưu license: " + (state.cloudUser || "chưa nhập"));
  };
  $("btnCheckWorkflowAccess").onclick = checkWorkflowAccess;
  $("btnSyncCloudWorkflows").onclick = syncCloudWorkflows;
  $("btnRestoreDefaultWorkflows").onclick = restoreDefaultWorkflows;
  $("btnOpenWorkflowIndex").onclick = () => chrome.tabs.create({ url: WORKFLOW_API_URL + "/workflows?key=" + encodeURIComponent(state.cloudUser || "") });

  $("workflowSelect").onchange = async () => {
    syncInputs();
    saveVisibleOutput();
    state.activeWorkflowId = $("workflowSelect").value;
    state.activeOutput = "workflow:" + state.activeWorkflowId;
    await saveRaw();
    renderAll();
    log("Đã chuyển workflow: " + currentWorkflow().name);
  };

  $("btnNewWorkflow").onclick = async () => {
    const name = prompt("Tên workflow mới:");
    if (!name) return;
    const id = name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "") || "workflow";
    if (state.workflows[id]) return alert("Workflow này đã tồn tại.");
    const wf = clone(SIMPLE_WORKFLOW);
    wf.id = id;
    wf.name = name;
    state.workflows[id] = wf;
    state.activeWorkflowId = id;
    state.activeOutput = "workflow:" + id;
    await saveRaw();
    renderAll();
    log("Đã tạo workflow mới: " + name);
  };

  $("btnDuplicateWorkflow").onclick = async () => {
    const current = currentWorkflow();
    const name = prompt("Tên workflow nhân bản:", current.name + " Copy");
    if (!name) return;
    const id = name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "") || "workflow";
    if (state.workflows[id]) return alert("Workflow này đã tồn tại.");
    const wf = clone(current);
    wf.id = id;
    wf.name = name;
    state.workflows[id] = wf;
    state.activeWorkflowId = id;
    state.activeOutput = "workflow:" + id;
    await saveRaw();
    renderAll();
    log("Đã nhân bản workflow: " + name);
  };

  $("btnDeleteWorkflow").onclick = async () => {
    const ids = Object.keys(state.workflows);
    if (ids.length <= 1) return alert("Cần giữ ít nhất 1 workflow.");
    const wf = currentWorkflow();
    if (!confirm("Xóa workflow: " + wf.name + "?")) return;
    delete state.workflows[wf.id];
    state.activeWorkflowId = Object.keys(state.workflows)[0];
    state.activeOutput = "workflow:" + state.activeWorkflowId;
    await saveRaw();
    renderAll();
  };

  $("btnEditWorkflow").onclick = () => {
    refreshWorkflowJsonEditor();
    $("workflowEditor").classList.remove("hidden");
  };
  $("btnCloseWorkflowEditor").onclick = () => $("workflowEditor").classList.add("hidden");
  $("btnSaveWorkflowJson").onclick = async () => {
    try {
      const wf = JSON.parse($("workflowJsonBox").value);
      if (!wf.id || !wf.name || !Array.isArray(wf.steps)) throw new Error("Workflow cần có id, name, steps[]");
      applyWorkflowPack(wf, { source: wf.source || "local" });
      await saveRaw();
      renderAll();
      log("Đã lưu Workflow JSON/Pack: " + wf.name);
    } catch (e) {
      alert("Workflow JSON không hợp lệ: " + e.message);
    }
  };
  $("btnResetWorkflow").onclick = async () => {
    if (!confirm("Reset workflow hiện tại về FE mặc định?")) return;
    const wf = clone(FE_WORKFLOW);
    state.workflows[wf.id] = wf;
    state.activeWorkflowId = wf.id;
    await saveRaw();
    renderAll();
  };

  $("btnSaveWorkflowPack").onclick = saveCurrentWorkflowPack;
  $("btnExportWorkflowPack").onclick = exportCurrentWorkflowPack;
  $("btnImportWorkflowPack").onclick = () => $("workflowImportFile").click();
  $("workflowImportFile").onchange = e => e.target.files[0] && importWorkflowPackFile(e.target.files[0]);
  $("btnDuplicateForProject").onclick = duplicateWorkflowForProject;

  $("stepSelect").onchange = () => {
    const step = stepById($("stepSelect").value);
    $("promptBox").value = step?.prompt || "";
  };
  $("btnPromptEditor").onclick = () => $("promptEditor").classList.toggle("hidden");
  $("btnClosePromptEditor").onclick = () => $("promptEditor").classList.add("hidden");
  $("btnSaveStepPrompt").onclick = saveCurrentStepPrompt;
  $("btnSavePromptAndWorkflow").onclick = saveStepPromptAndWorkflow;

  $("btnSaveOutput").onclick = async () => { await saveAllFromUI(); log("Đã lưu output."); };
  $("btnCopyOutput").onclick = async () => { await navigator.clipboard.writeText($("outputBox").value); log("Đã copy output."); };
  $("btnExportTxt").onclick = exportTXT;
});
