KOVA Content Assistant Extension v4.1.3
=======================================

Bản v4.1.1 là bản tối ưu sau v4.1.

Điểm mới
--------
1. License input được chuyển thành password.
2. UI/log chỉ hiển thị license dạng rút gọn, ví dụ:
   KOVA-L...6VZT
3. Có nút Đổi license.
4. Thêm biến prompt mới:
   {{SKELETON_Chuong_cuoi}}

Biến {{SKELETON_Chuong_cuoi}}
-----------------------------
Biến này tự lấy riêng phần dàn khung của Chapter cuối từ output Skeleton.

Ví dụ Skeleton có:
Chapter 1
...
Chapter 2
...
Chapter 10
...

Khi prompt dùng:
{{SKELETON_Chuong_cuoi}}

Extension sẽ thay bằng riêng block:
Chapter 10
...

Nếu không đọc được số chương, extension fallback lấy block Chapter/Chương cuối cùng trong Skeleton.

Biến bổ sung
------------
{{SKELETON_CHUONG_CUOI}}      // alias uppercase, tương đương biến trên
{{SKELETON_CHAPTER_CURRENT}}  // lấy skeleton của chapter hiện tại nếu xác định được chapterNumber

Cách dùng cho prompt Chương cuối
--------------------------------
Trong prompt B6 Chương cuối, có thể dùng:

Dàn khung riêng của chương cuối:
{{SKELETON_Chuong_cuoi}}

Thay vì đưa toàn bộ:
{{SKELETON}}

Worker
------
Vẫn dùng Worker v4.1:
- /check?key=LICENSE
- /workflows?key=LICENSE

KV:
- license:KOVA-LIC-...
- workflow:FE-Stories
- workflow:HT-Stories
- workflow:VH-Stories

version.json nếu dùng GitHub public cho update:
{
  "version": "4.1.1",
  "notes": "Masked license input and added {{SKELETON_Chuong_cuoi}} variable.",
  "download_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant/raw/main/KOVA_Content_Assistant_Extension_v4_1_1.zip",
  "repo_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant"
}


v4.1.3
------
Fix lỗi không lưu license và tối ưu UI license:
- Lưu license ổn định vào storage.
- Sau khi lưu, ô nhập license tự ẩn.
- Chỉ hiển thị license rút gọn.
- Có nút Xóa license để xóa license lưu trên máy.
- Không log full license.

version.json:
{
  "version": "4.1.3",
  "notes": "Fixed license saving and stable hidden license UX.",
  "download_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant/raw/main/KOVA_Content_Assistant_Extension_v4_1_3.zip",
  "repo_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant"
}
