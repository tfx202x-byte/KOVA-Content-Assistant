KOVA Content Assistant Extension v3.1
=====================================

Bản v3.1 là bản tối ưu hơn cho nhiều dự án.

Điểm mới lớn nhất
-----------------
Thêm Project Config Editor.

Thay vì mỗi dự án phải sửa từng prompt B1, B2, B3, B4, B5, B6, B7, bạn chỉ cần sửa một cấu hình chung:

- projectName
- language
- channelDNA
- storyWorld
- targetLength
- chapterLength
- pov
- audience
- styleRules
- forbiddenRules
- exportMode

Sau đó toàn bộ prompt trong workflow có thể tự dùng các biến này.

Biến mới trong prompt
---------------------
{{PROJECT_NAME}}
{{LANGUAGE}}
{{CHANNEL_DNA}}
{{STORY_WORLD}}
{{TARGET_LENGTH}}
{{CHAPTER_LENGTH}}
{{STYLE_RULES}}
{{FORBIDDEN_RULES}}
{{PROJECT_CONFIG}}
{{CONFIG:pov}}
{{CONFIG:audience}}
{{CONFIG:projectName}}

Cách dùng tối ưu
----------------
1. Chọn workflow gần giống dự án mới.
2. Bấm "Sửa Project Config".
3. Đổi DNA, style, độ dài, luật cấm của dự án.
4. Không cần sửa từng prompt nếu workflow đã dùng biến config.
5. Chạy Auto Review / Auto Full như bình thường.

Khi nào cần sửa Workflow JSON?
------------------------------
Chỉ khi quy trình khác hẳn, ví dụ:
- không có chapter
- nhiều bước research hơn
- export theo kiểu khác
- auto loop khác

Nếu chỉ khác style/chủ đề/DNA kênh, chỉ sửa Project Config là đủ.

Update GitHub
-------------
Sau khi upload zip v3.1 lên repo, sửa version.json:

{
  "version": "3.1.0",
  "notes": "Added Project Config Editor to avoid editing prompts step by step.",
  "download_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant/raw/main/KOVA_Content_Assistant_Extension_v3_1.zip",
  "repo_url": "https://github.com/tfx202x-byte/KOVA-Content-Assistant"
}
